import os
from pathlib import Path

def combine_files_for_llm(root_dir, output_file, allowed_extensions=None):
    """
    지정된 폴더 내의 텍스트 기반 파일들을 읽어 하나의 파일로 병합합니다.
    """
    # 읽어들일 확장자 목록 (기본적으로 코드, 텍스트, 설정 파일 포함)
    if allowed_extensions is None:
        allowed_extensions = {'.py', '.yaml', '.yml', '.md', '.txt', '.csv'}
        
    root_path = Path(root_dir)
    
    with open(output_file, 'w', encoding='utf-8') as out_f:
        for file_path in root_path.rglob('*'):
            # 파일이면서 허용된 확장자인 경우만 처리
            if file_path.is_file() and file_path.suffix.lower() in allowed_extensions:
                # pycache 같은 불필요한 폴더 제외
                if '__pycache__' in file_path.parts:
                    continue
                    
                relative_path = file_path.relative_to(root_path)
                
                # 파일 구분자 작성
                out_f.write("=" * 80 + "\n")
                out_f.write(f"File PATH: {relative_path}\n")
                out_f.write("=" * 80 + "\n")
                
                # 파일 내용 읽고 쓰기
                try:
                    with open(file_path, 'r', encoding='utf-8') as in_f:
                        content = in_f.read()
                        out_f.write(content)
                        out_f.write("\n\n")
                except Exception as e:
                    out_f.write(f"파일을 읽는 중 오류 발생: {e}\n\n")

if __name__ == "__main__":
    # 합칠 대상이 되는 최상위 폴더 경로 (예: green-idc 폴더)
    # 실제 환경에 맞게 경로를 수정해주세요.
    target_directory = "./green-idc" 
    
    # 결과물이 저장될 파일 이름
    output_filename = "all_project_files_combined.txt"
    
    combine_files_for_llm(target_directory, output_filename)
    print(f"완료되었습니다! '{output_filename}' 파일을 확인해주세요.")