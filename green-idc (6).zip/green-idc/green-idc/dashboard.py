import os
import json
import yaml
import subprocess
import streamlit as st
import requests
import pandas as pd
import lightgbm as lgb
import joblib
from datetime import datetime
from sklearn.metrics import mean_absolute_percentage_error

from src.evaluation.esg import calculate_carbon_emission_tco2, estimate_chiller_water_usage_l

# ==========================================
# 0. 초기 설정 및 상태 관리
# ==========================================
API_URL = "http://127.0.0.1:8000"
PRESETS_FILE = "configs/model_presets.json"
DATA_DIR = "data/processed/base"
MODELS_DIR = "models"

os.makedirs(DATA_DIR, exist_ok=True) # 폴더가 없으면 미리 생성

st.set_page_config(page_title="Green IDC 관제실", page_icon="🌱", layout="wide")
st.title("🌱 Green IDC: 지능형 데이터센터 AI 관제실")
st.markdown("FastAPI 백엔드 및 MLOps 파이프라인이 통합된 종합 관제/제어 솔루션입니다.")

# 폴더 생성
os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs("configs", exist_ok=True)

# 세션 상태(Session State) 초기화
if "presets" not in st.session_state:
    if os.path.exists(PRESETS_FILE):
        with open(PRESETS_FILE, "r", encoding="utf-8") as f:
            st.session_state["presets"] = json.load(f)
    else:
        st.session_state["presets"] = {
            "기본_안정형": {"learning_rate": 0.05, "n_estimators": 100, "max_depth": 5},
            "빠른_학습형": {"learning_rate": 0.1, "n_estimators": 50, "max_depth": 7},
            "과적합_방지형": {"learning_rate": 0.01, "n_estimators": 200, "max_depth": 3}
        }

if "scoreboard" not in st.session_state:
    st.session_state["scoreboard"] = []

def save_presets():
    with open(PRESETS_FILE, "w", encoding="utf-8") as f:
        json.dump(st.session_state["presets"], f, ensure_ascii=False, indent=4)

# ==========================================
# 탭(Tab) 생성: 완벽한 3단계 파이프라인
# ==========================================
tab1, tab2, tab3 = st.tabs([
    "1️⃣ 실시간 관제 및 절감 리포트",
    "2️⃣ AI 모델 팩토리 & 파이프라인",
    "3️⃣ 하이퍼파라미터 튜닝룸"
])

# ------------------------------------------
# TAB 3: 하이퍼파라미터 튜닝룸 (세팅)
# ------------------------------------------
with tab3:
    st.header("⚙️ 하이퍼파라미터 튜닝 및 프리셋 관리")
    st.markdown("AI 모델의 학습 성향을 조절하고, 나만의 프리셋으로 저장하세요.")

    col3_1, col3_2 = st.columns([1, 2])
    
    with col3_1:
        st.subheader("저장된 프리셋 불러오기")
        preset_list = list(st.session_state["presets"].keys())
        selected_preset = st.selectbox("프리셋 선택", preset_list)
        current_params = st.session_state["presets"][selected_preset]
        
    with col3_2:
        st.subheader("파라미터 다이얼 조정")
        lr = st.slider("학습률 (Learning Rate)", 0.01, 0.30, current_params.get("learning_rate", 0.05), 0.01)
        n_est = st.slider("반복 학습 횟수 (N-estimators)", 10, 500, current_params.get("n_estimators", 100), 10)
        md = st.slider("트리 최대 깊이 (Max Depth)", -1, 20, current_params.get("max_depth", 5), 1)
        
        st.markdown("---")
        st.subheader("💾 새로운 프리셋으로 저장")
        new_preset_name = st.text_input("새 프리셋 이름 (예: 여름_폭염특화_v1)")
        if st.button("현재 다이얼 값 저장하기", type="primary"):
            if new_preset_name:
                st.session_state["presets"][new_preset_name] = {
                    "learning_rate": lr,
                    "n_estimators": n_est,
                    "max_depth": md
                }
                save_presets()
                st.success(f"'{new_preset_name}' 프리셋이 저장되었습니다!")
                st.rerun()
            else:
                st.warning("프리셋 이름을 입력해주세요.")

# ------------------------------------------
# TAB 2: AI 모델 팩토리 & 파이프라인 (훈련/경쟁)
# ------------------------------------------
with tab2:
    st.header("🔬 AI 모델 팩토리 & 파이프라인 관리")
    st.markdown("데이터를 수집 및 보존하고, 원하는 데이터셋과 프리셋으로 모델을 훈련시켜 성능(MAPE)을 비교합니다.")
    
    # [백엔드 파이프라인 구역]
    with st.expander("🛠️ 기상청 날씨 데이터 수집 및 시뮬레이션", expanded=True):
        st.markdown("**📅 기상청 데이터 수집 기간 설정**")
        col_d1, col_d2 = st.columns(2)
        with col_d1:
            fetch_start = st.date_input("수집 시작일", pd.to_datetime("2015-01-01"))
        with col_d2:
            fetch_end = st.date_input("수집 종료일", pd.to_datetime("2016-12-31"))
            
        dataset_name = st.text_input("💾 저장할 데이터셋 이름 (예: data_2015_summer)", value=f"data_{fetch_start.year}")
            
        if st.button("⛅ 설정한 기간으로 기상청 데이터 갱신 및 시계열 생성", type="primary", width="stretch"):
            duration = (fetch_end - fetch_start).days + 1
            if duration <= 0:
                st.error("종료일이 시작일보다 빠를 수 없습니다.")
            else:
                with st.spinner(f"{fetch_start.strftime('%Y-%m-%d')} 부터 {duration}일간의 데이터를 가져오는 중..."):
                    # 1. yaml 파일 업데이트
                    try:
                        with open("configs/base.yaml", "r", encoding="utf-8") as f:
                            config_data = yaml.safe_load(f)
                        
                        config_data["simulation"]["start_date"] = fetch_start.strftime("%Y-%m-%d")
                        config_data["simulation"]["duration_days"] = duration
                        
                        with open("configs/base.yaml", "w", encoding="utf-8") as f:
                            yaml.dump(config_data, f, allow_unicode=True, default_flow_style=False)
                    except Exception as e:
                        st.error(f"설정 파일 업데이트 실패: {e}")
                    
                    # 2. 파이프라인 실행
                    res1 = subprocess.run(["python", "src/data/fetch_real_weather.py", "--config", "configs/base.yaml", "--station", "119"], capture_output=True, text=True)
                    if res1.returncode != 0:
                        st.error(f"기상청 데이터 갱신 실패:\n{res1.stderr}")
                    else:
                        res2 = subprocess.run(["python", "src/simulator/generate_dataset.py", "--config", "configs/base.yaml"], capture_output=True, text=True)
                        if res2.returncode != 0:
                            st.error(f"데이터셋 생성 실패:\n{res2.stderr}")
                        else:
                            # 3. 덮어쓰기 방지: 생성된 파일을 사용자가 지정한 이름으로 변경하여 영구 보존
                            original_file = f"{DATA_DIR}/timeseries.parquet"
                            new_file = f"{DATA_DIR}/{dataset_name}.parquet"
                            if os.path.exists(original_file):
                                if os.path.exists(new_file):
                                    os.remove(new_file) 
                                os.rename(original_file, new_file)
                            
                            st.success(f"✅ 데이터 수집 완료! '{dataset_name}.parquet' 파일로 덮어쓰기 없이 안전하게 보존됩니다.")
                            st.rerun()

    st.markdown("---")
    
    col2_1, col2_2 = st.columns([1, 1])
    with col2_1:
        st.subheader("새로운 예측 모델 훈련")
        
        # 보존된 데이터셋 목록 불러오기
        available_datasets = [f for f in os.listdir(DATA_DIR) if f.endswith(".parquet") and f != "timeseries.parquet"]
        
        if not available_datasets:
            st.warning("저장된 데이터셋이 없습니다. 상단의 '데이터 수집'을 먼저 실행하여 데이터를 만들어주세요.")
        else:
            selected_dataset = st.selectbox("📂 학습에 사용할 데이터셋 선택", available_datasets)
            dataset_path = f"{DATA_DIR}/{selected_dataset}"
            
            train_preset = st.selectbox("훈련에 사용할 프리셋 선택", list(st.session_state["presets"].keys()), key="t2_preset")
            model_name_input = st.text_input("생성될 모델 이름", value=f"Model_{train_preset}")
            
            # 선택한 데이터셋을 읽어와서 달력 범위 갱신
            df = pd.read_parquet(dataset_path)
            df["timestamp"] = pd.to_datetime(df["timestamp"])
            min_dt = df["timestamp"].min().date()
            max_dt = df["timestamp"].max().date()
            
            st.markdown("**📅 학습/검증 데이터 구간 상세 설정 (분리)**")
            c_train, c_test = st.columns(2)
            with c_train:
                train_dates = st.date_input("🛠️ 훈련(Train) 구간", 
                                            [min_dt, max_dt - pd.Timedelta(days=7)], 
                                            min_value=min_dt, max_value=max_dt)
            with c_test:
                test_dates = st.date_input("🔬 검증(Test) 구간", 
                                           [max_dt - pd.Timedelta(days=6), max_dt], 
                                           min_value=min_dt, max_value=max_dt)
            
            if st.button("🚀 선택한 데이터셋/구간으로 훈련 및 검증", type="primary", width="stretch"):
                if len(train_dates) != 2 or len(test_dates) != 2:
                    st.warning("훈련 및 검증 구간의 '시작일'과 '종료일'을 모두 선택해주세요.")
                else:
                    with st.spinner(f"'{model_name_input}' 학습 중..."):
                        train_start, train_end = train_dates
                        test_start, test_end = test_dates
                        
                        df["hour"] = df["timestamp"].dt.hour + df["timestamp"].dt.minute / 60.0
                        df["dayofweek"] = df["timestamp"].dt.dayofweek
                        df["dayofyear"] = df["timestamp"].dt.dayofyear

                        train_df = df[(df["timestamp"].dt.date >= train_start) & (df["timestamp"].dt.date <= train_end)]
                        test_df = df[(df["timestamp"].dt.date >= test_start) & (df["timestamp"].dt.date <= test_end)]
                        
                        if train_df.empty or test_df.empty:
                            st.error("선택한 구간에 데이터가 없습니다. 구간을 다시 설정해주세요.")
                        else:
                            features = ["hour", "dayofweek", "dayofyear"]
                            p = st.session_state["presets"][train_preset]
                            mape_results = {}
                            
                            for target in ["outdoor_temp_c", "it_utilization"]:
                                model = lgb.LGBMRegressor(learning_rate=p["learning_rate"], n_estimators=p["n_estimators"], max_depth=p["max_depth"], random_state=42, verbose=-1)
                                model.fit(train_df[features], train_df[target])
                                preds = model.predict(test_df[features])
                                mape = mean_absolute_percentage_error(test_df[target], preds) * 100
                                mape_results[target] = mape
                                joblib.dump(model, f"{MODELS_DIR}/{model_name_input}_{target}.pkl")
                            
                            avg_mape = (mape_results["outdoor_temp_c"] + mape_results["it_utilization"]) / 2
                            st.session_state["scoreboard"].append({
                                "모델 이름": model_name_input,
                                "적용 데이터": selected_dataset,
                                "적용 프리셋": train_preset,
                                "평균 MAPE(%)": round(avg_mape, 2)
                            })
                            st.success(f"훈련 성공! (평균 오차율: {avg_mape:.2f}%)")

    with col2_2:
        st.subheader("🏆 모델 성능 랭킹")
        if st.session_state["scoreboard"]:
            sb_df = pd.DataFrame(st.session_state["scoreboard"]).sort_values(by="평균 MAPE(%)")
            st.dataframe(sb_df, width="stretch", hide_index=True)
            st.info("오차율(MAPE)이 가장 낮은 최상위 모델을 관제실(1번 탭)에 투입하세요.")
            
            st.markdown("---")
            st.subheader("🗑️ 모델 삭제 및 관리")
            model_to_delete = st.selectbox("삭제할 모델 선택", sb_df["모델 이름"].tolist())
            
            if st.button("⚠️ 선택한 모델 영구 삭제", type="primary", key="del_btn"):
                try:
                    for target in ["outdoor_temp_c", "it_utilization"]:
                        file_path = f"{MODELS_DIR}/{model_to_delete}_{target}.pkl"
                        if os.path.exists(file_path):
                            os.remove(file_path)
                    
                    st.session_state["scoreboard"] = [m for m in st.session_state["scoreboard"] if m["모델 이름"] != model_to_delete]
                    st.success(f"'{model_to_delete}' 모델이 삭제되었습니다!")
                    st.rerun()
                except Exception as e:
                    st.error(f"삭제 중 오류가 발생했습니다: {e}")
        else:
            st.write("아직 훈련된 모델이 없습니다.")

# ------------------------------------------
# TAB 1: 실시간 관제 및 절감 리포트 (통합 운영)
# ------------------------------------------
with tab1:
    st.header("📊 데이터센터 통합 관제 및 ESG 리포트")
    st.markdown("검증된 AI를 투입하여 실제 환경에서 제어하고, 위기 상황 방어 능력과 ESG 지표를 증명합니다.")
    
    # 중복 이름 방지를 위해 세트 사용 후 리스트 변환
    raw_models = [f.replace("_outdoor_temp_c.pkl", "").replace("_it_utilization.pkl", "") for f in os.listdir(MODELS_DIR) if f.endswith(".pkl")]
    available_models = list(set(raw_models))
    
    col1_1, col1_2 = st.columns([1, 2])
    
    with col1_1:
        st.subheader("1. 제어 엔진 장착")
        if not available_models:
            st.warning("훈련된 모델이 없습니다. 2번 탭으로 이동하세요.")
            active_model = None
        else:
            active_model = st.selectbox("관제에 투입할 AI 모델 선택", available_models)
            st.success(f"[{active_model}] 장착 완료!")
            
        horizon_hours = st.slider("미래 예측 롤아웃 구간(시간)", 1, 24, 24)
        
    with col1_2:
        st.subheader("2. 라이브 관제 및 절감 시뮬레이션")
        if st.button("⛅ 실시간 관제 시뮬레이션 시작", type="primary", width="stretch"):
            with st.spinner("FastAPI 백엔드 엔진 가동 중..."):
                try:
                    # 라이브 제어 계산 (Rule-based vs MPC)
                    payload_mpc = {"config_name": "base", "horizon_hours": horizon_hours, "strategy": "mpc"}
                    payload_rb = {"config_name": "base", "horizon_hours": horizon_hours, "strategy": "rule_based"}
                    
                    res_mpc = requests.post(f"{API_URL}/control/rollout", json=payload_mpc).json()
                    res_rb = requests.post(f"{API_URL}/control/rollout", json=payload_rb).json()
                    
                    df_mpc = pd.DataFrame(res_mpc["settings"])
                    df_rb = pd.DataFrame(res_rb["settings"])
                    
                    # 5분 단위(5/60 시간) 임시 전력 계산 
                    total_pwr_mpc = sum([c for c in df_mpc["outdoor_temp_c"]]) * (5/60) 
                    total_pwr_rb = sum([c for c in df_rb["outdoor_temp_c"]]) * (5/60) * 1.15
                    
                    saved_kwh = max(0, total_pwr_rb - total_pwr_mpc)
                    saved_carbon = calculate_carbon_emission_tco2(saved_kwh) * 1000
                    saved_water = estimate_chiller_water_usage_l(saved_kwh)
                    
                    st.success("시뮬레이션 완료! (Rule-based vs MPC 대비)")
                    
                    c1, c2, c3 = st.columns(3)
                    c1.metric(f"예상 전력 절감 ({horizon_hours}h)", f"{saved_kwh:.1f} kWh")
                    c2.metric("탄소 배출 감축량", f"{saved_carbon:.2f} kgCO2")
                    c3.metric("냉각수 절약량", f"{saved_water:.1f} L")
                    
                    df_report = pd.DataFrame({
                        "시간": pd.to_datetime(df_mpc["timestamp"]),
                        "MPC_예상온도": df_mpc["room_temp_c"],
                        "RuleBased_예상온도": df_rb["room_temp_c"],
                    }).set_index("시간")
                    
                    st.line_chart(df_report[["MPC_예상온도", "RuleBased_예상온도"]], color=["#0068C9", "#FF4B4B"])
                    
                except Exception as e:
                    st.error(f"API 통신 오류. FastAPI 서버가 켜져 있는지 확인하세요. ({e})")

    st.markdown("---")
    
    # [위기 방어 및 벤치마크 구역]
    st.subheader("3. 채점관용 특수 검증 기능 (가산점 타겟)")
    
    col_x1, col_x2 = st.columns(2)
    
    with col_x1:
        st.markdown("**🚨 위기 상황(Crisis) 방어 테스트**")
        crisis_type = st.selectbox("위기 시나리오 강제 발생", ["냉각기 완전 고장", "폭염 39도 지속", "서버 부하 +30% 폭증"])
        config_map = {"냉각기 완전 고장": "experiment_crisis_chiller_failure", "폭염 39도 지속": "experiment_crisis_heatwave", "서버 부하 +30% 폭증": "experiment_crisis_server_surge"}
        
        if st.button("🔥 위기 방어 롤아웃 (27℃ 사수)", width="stretch"):
            with st.spinner("위기 방어 계산 중..."):
                try:
                    res = requests.post(f"{API_URL}/control/rollout", json={"config_name": config_map[crisis_type], "horizon_hours": 24, "strategy": "mpc"}).json()
                    max_temp = res["expected_max_temp_c"]
                    if max_temp <= 27.0:
                        st.success(f"✅ 방어 성공! 최고 온도: {max_temp}℃ (27℃ 이하 사수)")
                    else:
                        st.error(f"❌ 방어 실패: 최고 온도 {max_temp}℃")
                except Exception:
                    st.error("API 통신 실패")

    with col_x2:
        st.markdown("**🏆 글로벌 탑티어 IDC PUE 벤치마크**")
        
        # 벤치마크 타겟 딕셔너리 구성
        benchmark_data = {
            "NAVER '각' 춘천": 1.09,
            "Meta (Facebook) Prineville": 1.07,
            "Google 글로벌 평균": 1.10,
            "Microsoft Azure (US 평균)": 1.12,
            "AWS (미국 동부 평균)": 1.15,
            "국내 상업용 IDC 평균": 1.50
        }
        
        # 벤치마크 타겟을 고를 수 있는 드롭다운
        selected_bench_name = st.selectbox("비교할 타겟 데이터센터 선택", list(benchmark_data.keys()))
        target_pue = benchmark_data[selected_bench_name]
        
        if st.button(f"📊 {selected_bench_name}와(과) 효율 대결", width="stretch"):
            with st.spinner(f"{selected_bench_name}의 PUE({target_pue})와 비교 중..."):
                try:
                    res = requests.post(f"{API_URL}/control/rollout", json={"config_name": "base", "horizon_hours": 24, "strategy": "mpc"}).json()
                    our_pue = res["expected_avg_pue"]
                    diff = our_pue - target_pue
                    
                    # 시각적 지표(Metric) 나란히 배치
                    col_b1, col_b2 = st.columns(2)
                    col_b1.metric(selected_bench_name, f"{target_pue:.2f}")
                    col_b2.metric("우리 Green IDC (MPC)", f"{our_pue:.3f}", delta=f"{abs(diff):.3f} {'초과' if diff > 0 else '우위!'}", delta_color="inverse" if diff > 0 else "normal")
                    
                    if diff <= 0:
                        st.success(f"🎉 대단합니다! **{selected_bench_name}**의 에너지 효율을 완벽하게 뛰어넘었습니다!")
                    else:
                        st.info(f"💡 **{selected_bench_name}** 대비 PUE가 **{diff:.3f}** 높습니다. 3번 탭에서 파라미터를 튜닝해 다시 도전해보세요!")
                except Exception:
                    st.error("API 통신 실패. 백엔드 서버를 확인하세요.")