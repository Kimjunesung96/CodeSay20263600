"""
run_thermal_simulation.py

room_dynamics.step_room_dynamics()를 90일 전체에 대해 순차 실행(온도를 이어받음).
config.crisis_scenarios에 정의된 시나리오를 시간대별로 적용해서
"위기 상황에서도 27도 이하를 유지하는지" 검증할 수 있는 전체 시계열을 생성한다.

기존 generate_dataset.py의 날씨/부하 생성 로직을 재사용하고,
독립적 계산(run_cooling_step) 대신 상태 유지형(step_room_dynamics)으로 교체.

실행: PYTHONPATH=. python3 src/simulator/run_thermal_simulation.py --config configs/base.yaml
"""
import argparse
import os
import numpy as np
import pandas as pd

from src.config_loader import load_config
from src.thermal_model.room_dynamics import step_room_dynamics
from src.simulator.generate_dataset import (
    generate_weather_series, generate_utilization_series, try_load_real_weather,
)


def apply_crisis_scenarios(hour_index: float, base_outdoor_temp: float, base_utilization: float, cfg):
    """
    현재 시각(hour_index, 시뮬레이션 시작 후 경과 시간)에 위기시나리오가 적용 중이면
    외기온/부하율/칠러용량비율을 조정해서 리턴.
    """
    crisis = cfg.crisis
    outdoor_temp = base_outdoor_temp
    utilization = base_utilization
    chiller_capacity_ratio = 1.0

    hw = crisis.heatwave
    if hw.enabled and hw.start_hour <= hour_index < hw.start_hour + hw.duration_hours:
        outdoor_temp = hw.outdoor_temp_override_c

    surge = crisis.server_surge
    if surge.enabled:
        utilization = min(1.0, utilization * surge.utilization_multiplier)

    fail = crisis.chiller_failure
    if fail.enabled and fail.start_hour <= hour_index < fail.start_hour + fail.duration_hours:
        chiller_capacity_ratio = fail.capacity_ratio

    return outdoor_temp, utilization, chiller_capacity_ratio


def run_thermal_simulation(cfg) -> pd.DataFrame:
    rng = np.random.default_rng(cfg.seed)
    sim_cfg = cfg.simulation

    periods = int(sim_cfg.duration_days * 24 * 60 / sim_cfg.interval_minutes)
    timestamps = pd.date_range(
        start=sim_cfg.start_date, periods=periods, freq=f"{sim_cfg.interval_minutes}min"
    )

    base_outdoor_temp = try_load_real_weather(cfg, timestamps)
    if base_outdoor_temp is None:
        base_outdoor_temp = generate_weather_series(timestamps, sim_cfg, rng)
    base_utilization = generate_utilization_series(timestamps, cfg.datacenter, rng)

    dt_seconds = sim_cfg.interval_minutes * 60
    room_temp = cfg.thermal.initial_room_temp_c

    rows = []
    for i, ts in enumerate(timestamps):
        hour_index = i * sim_cfg.interval_minutes / 60.0

        outdoor_temp, utilization, chiller_ratio = apply_crisis_scenarios(
            hour_index, float(base_outdoor_temp[i]), float(base_utilization[i]), cfg
        )

        result = step_room_dynamics(
            room_temp_c=room_temp,
            outdoor_temp_c=outdoor_temp,
            utilization=utilization,
            dt_seconds=dt_seconds,
            num_servers=cfg.datacenter.num_servers,
            rated_power_per_server_kw=cfg.datacenter.rated_power_per_server_kw,
            airflow_m3_per_s=cfg.thermal.airflow_m3_per_s,
            air_density=cfg.thermal.air_density,
            specific_heat_air=cfg.thermal.specific_heat_air,
            room_thermal_mass_kj_per_c=cfg.thermal.room_thermal_mass_kj_per_c,
            free_cooling_threshold_c=cfg.cooling.free_cooling_threshold_c,
            mixed_mode_threshold_c=cfg.cooling.mixed_mode_threshold_c,
            chiller_cop_rated=cfg.cooling.chiller_cop_rated,
            chiller_cop_min=cfg.cooling.chiller_cop_min,
            cop_ref_outdoor_temp_c=cfg.cooling.cop_ref_outdoor_temp_c,
            chiller_max_capacity_kw=cfg.cooling.chiller_max_capacity_kw,
            target_temp_c=cfg.thermal.target_temp_c,
            chiller_capacity_ratio=chiller_ratio,
            temp_safety_min_c=cfg.thermal.temp_safety_min_c,
            temp_safety_max_c=cfg.thermal.temp_safety_max_c,
        )
        room_temp = result.room_temp_c

        rows.append({
            "timestamp": ts,
            "hour_index": hour_index,
            "outdoor_temp_c": outdoor_temp,
            "it_utilization": utilization,
            "room_temp_c": result.room_temp_c,
            "it_power_kw": result.it_power_kw,
            "free_cooling_kw": result.free_cooling_kw,
            "chiller_power_kw": result.chiller_power_kw,
            "chiller_cop": result.chiller_cop,
            "unmet_load_kw": result.unmet_load_kw,
            "total_power_kw": result.total_power_kw,
            "pue": result.pue,
            "mode": result.mode,
            "chiller_capacity_ratio": chiller_ratio,
            "temp_violation": result.temp_violation,
        })

    return pd.DataFrame(rows)


def summarize(df: pd.DataFrame, cfg):
    total = len(df)
    violation_count = df["temp_violation"].sum()
    violation_rate = violation_count / total * 100

    print(f"총 스텝: {total:,}")
    print(f"온도 위반(18~27도 벗어남) 스텝: {violation_count:,} ({violation_rate:.2f}%)")
    print(f"룸 온도 범위: {df['room_temp_c'].min():.2f}C ~ {df['room_temp_c'].max():.2f}C")
    print(f"평균 PUE: {df['pue'].mean():.4f}")
    print(f"모드 비율:\n{df['mode'].value_counts(normalize=True)}")

    if df["unmet_load_kw"].max() > 0:
        worst = df.loc[df["unmet_load_kw"].idxmax()]
        print(f"\n최대 미처리 부하: {worst['unmet_load_kw']:.1f}kW @ {worst['timestamp']} (룸온도 {worst['room_temp_c']:.2f}C)")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, default="configs/base.yaml")
    args = parser.parse_args()

    cfg = load_config(args.config)
    df = run_thermal_simulation(cfg)

    out_dir = os.path.join(cfg.processed_data_dir, cfg.experiment_name)
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "thermal_timeseries.parquet")
    df.to_parquet(out_path, index=False)

    print(f"생성 완료: {out_path}\n")
    summarize(df, cfg)


if __name__ == "__main__":
    main()
