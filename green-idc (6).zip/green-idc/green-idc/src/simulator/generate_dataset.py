"""
generate_dataset.py

가상의 90일치, 5분 간격 데이터센터 운영 데이터를 생성한다.
1) 기상(외기온) 시계열 생성: 계절 변화 + 일교차 + 노이즈 (합성)
   -> data/raw/real_weather_*.parquet 캐시가 있으면 그걸 우선 사용 (실제 기상청 데이터)
2) IT 부하율 시계열 생성: 업무시간 패턴 + 평일/주말 패턴 + 노이즈
3) 각 시점마다 cooling_model.run_cooling_step() 호출 -> PUE 등 산출
4) data/processed/<experiment_name>/timeseries.parquet 로 저장

실행: PYTHONPATH=. python3 src/simulator/generate_dataset.py --config configs/base.yaml
"""
import argparse
import glob
import os
import numpy as np
import pandas as pd

from src.config_loader import load_config
from src.thermal_model.cooling_model import run_cooling_step


def try_load_real_weather(cfg, timestamps: pd.DatetimeIndex) -> np.ndarray | None:
    """
    data/raw/real_weather_*.parquet 캐시 중 이 시뮬레이션 기간을 커버하는 게 있으면
    실제 관측 기온을 리턴. 없으면 None (호출부에서 합성 데이터로 폴백).
    fetch_real_weather.py로 미리 캐시를 만들어둬야 함.

    ASOS는 시간단위 관측이라 하루의 마지막 55분(23:05~23:55)처럼 보간 범위 밖의
    시각이 생길 수 있음 -> ffill/bfill로 가장자리를 메워서 사용.
    """
    pattern = os.path.join(cfg.raw_data_dir, "real_weather_*.parquet")
    candidates = sorted(glob.glob(pattern))
    if not candidates:
        return None

    for path in candidates:
        try:
            df = pd.read_parquet(path)
        except Exception:
            continue
        df = df.set_index("timestamp").sort_index()

        # 최소한 대부분 겹치는지 체크 (완전 무관한 캐시 파일 걸러내기용)
        overlap = (df.index.min() <= timestamps.max()) and (df.index.max() >= timestamps.min())
        if not overlap:
            continue

        aligned = df.reindex(timestamps)["outdoor_temp_c"]
        aligned = aligned.ffill().bfill()  # 가장자리(마지막 55분 등) 메우기

        if aligned.isna().any():
            continue  # 그래도 못 채우면(중간에 큰 구멍) 이 파일은 포기

        print(f"[실데이터] {path} 사용 (합성 날씨 대신 실제 기상청 관측값 적용)")
        return aligned.values

    return None




def try_load_real_utilization(cfg, timestamps: pd.DatetimeIndex) -> np.ndarray | None:
    """
    data/raw/real_it_load.parquet 캐시가 있으면 실제 IT 부하율을 리턴.
    없으면 None을 리턴하여 합성 데이터로 폴백.
    """
    cache_path = os.path.join(cfg.raw_data_dir, "real_it_load.parquet")
    if not os.path.exists(cache_path):
        return None

    try:
        df = pd.read_parquet(cache_path).set_index("timestamp").sort_index()
        overlap = (df.index.min() <= timestamps.max()) and (df.index.max() >= timestamps.min())
        if not overlap:
            return None

        aligned = df.reindex(timestamps)["it_utilization"]
        aligned = aligned.ffill().bfill() 
        
        if aligned.isna().any():
            return None
            
        print(f"[실데이터] {cache_path} 사용 (합성 IT 부하 대신 실제 클러스터 트레이스 적용)")
        return aligned.values
    except Exception:
        return None


def generate_weather_series(timestamps: pd.DatetimeIndex, sim_cfg, rng: np.random.Generator) -> np.ndarray:
    """계절(연중) + 일교차(24h) + 랜덤노이즈를 합성한 외기온 시계열(°C)."""
    day_of_year = timestamps.dayofyear.values.astype(float)
    hour_of_day = (timestamps.hour + timestamps.minute / 60.0).values

    # 계절 성분: 여름(북반구, 7월경) 최고가 되도록 cos 기반
    seasonal = sim_cfg.weather_seasonal_amplitude_c * np.cos(
        2 * np.pi * (day_of_year - 200) / 365.0
    ) * -1  # day 200(7월 중순) 근처에서 최댓값이 되도록 부호 반전

    # 일교차 성분: 새벽 5시경 최저, 오후 3시경 최고
    daily = sim_cfg.weather_daily_amplitude_c * np.sin(
        2 * np.pi * (hour_of_day - 9) / 24.0
    )

    noise = rng.normal(0, sim_cfg.weather_noise_std_c, size=len(timestamps))

    temp = sim_cfg.weather_base_temp_c + seasonal + daily + noise
    return temp


def generate_utilization_series(timestamps: pd.DatetimeIndex, dc_cfg, rng: np.random.Generator) -> np.ndarray:
    """업무시간대(9-18시) 높고 새벽에 낮은 부하율 패턴 + 평일/주말 차이 + 노이즈."""
    hour_of_day = (timestamps.hour + timestamps.minute / 60.0).values
    is_weekend = timestamps.dayofweek >= 5

    # 하루 패턴: 업무시간대 피크가 되는 완만한 사인파 (0~1 범위로 정규화)
    daily_pattern = 0.5 + 0.5 * np.sin(2 * np.pi * (hour_of_day - 15) / 24.0)

    # 주말엔 부하가 다소 낮음 (배치작업 등으로 완전히 0은 아님)
    weekend_factor = np.where(is_weekend, 0.8, 1.0)

    base_range = dc_cfg.max_it_utilization - dc_cfg.min_it_utilization
    utilization = dc_cfg.min_it_utilization + base_range * daily_pattern * weekend_factor

    noise = rng.normal(0, 0.03, size=len(timestamps))
    utilization = np.clip(utilization + noise, dc_cfg.min_it_utilization, dc_cfg.max_it_utilization)
    return utilization


def run_simulation(cfg) -> pd.DataFrame:
    rng = np.random.default_rng(cfg.seed)

    sim_cfg = cfg.simulation
    periods = int(sim_cfg.duration_days * 24 * 60 / sim_cfg.interval_minutes)
    timestamps = pd.date_range(
        start=sim_cfg.start_date,
        periods=periods,
        freq=f"{sim_cfg.interval_minutes}min",
    )

    outdoor_temp = try_load_real_weather(cfg, timestamps)
    if outdoor_temp is None:
        outdoor_temp = generate_weather_series(timestamps, sim_cfg, rng)
        
    # [수정된 부분] 실제 IT 부하 캐시 로딩 적용
    utilization = try_load_real_utilization(cfg, timestamps)
    if utilization is None:
        utilization = generate_utilization_series(timestamps, cfg.datacenter, rng)

    rows = []
    # 이하 기존 코드와 동일
    for ts, temp, util in zip(timestamps, outdoor_temp, utilization):
        result = run_cooling_step(
            outdoor_temp_c=float(temp),
            utilization=float(util),
            num_servers=cfg.datacenter.num_servers,
            rated_power_per_server_kw=cfg.datacenter.rated_power_per_server_kw,
            target_temp_c=cfg.thermal.target_temp_c,
            airflow_m3_per_s=cfg.thermal.airflow_m3_per_s,
            air_density=cfg.thermal.air_density,
            specific_heat_air=cfg.thermal.specific_heat_air,
            free_cooling_threshold_c=cfg.cooling.free_cooling_threshold_c,
            mixed_mode_threshold_c=cfg.cooling.mixed_mode_threshold_c,
            chiller_cop_rated=cfg.cooling.chiller_cop_rated,
            chiller_cop_min=cfg.cooling.chiller_cop_min,
            cop_ref_outdoor_temp_c=cfg.cooling.cop_ref_outdoor_temp_c,
        )
        rows.append({
            "timestamp": ts,
            "outdoor_temp_c": temp,
            "it_utilization": util,
            "it_power_kw": result.it_power_kw,
            "cooling_load_kw": result.cooling_load_kw,
            "free_cooling_kw": result.free_cooling_kw,
            "chiller_load_kw": result.chiller_load_kw,
            "chiller_cop": result.chiller_cop,
            "chiller_power_kw": result.chiller_power_kw,
            "cooling_power_kw": result.cooling_power_kw,
            "total_power_kw": result.total_power_kw,
            "pue": result.pue,
            "mode": result.mode,
        })

    df = pd.DataFrame(rows)
    return df


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, default="configs/base.yaml")
    args = parser.parse_args()

    cfg = load_config(args.config)
    df = run_simulation(cfg)

    out_dir = os.path.join(cfg.processed_data_dir, cfg.experiment_name)
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "timeseries.parquet")
    df.to_parquet(out_path, index=False)

    print(f"생성 완료: {len(df):,} rows -> {out_path}")
    print(df[["outdoor_temp_c", "it_utilization", "pue", "mode"]].describe(include="all"))
    print("\n모드별 비율:")
    print(df["mode"].value_counts(normalize=True))


if __name__ == "__main__":
    main()
