"""
weather_api.py

기상청_지상(종관, ASOS) 시간자료 조회서비스 연동.
https://apis.data.go.kr/1360000/AsosHourlyInfoService/getWthrDataList

서비스키는 코드에 하드코딩하지 않고 환경변수 WEATHER_API_KEY 로 받는다.

사용법 (PowerShell):
    $env:WEATHER_API_KEY="발급받은_인증키(디코딩된 값)"
    PYTHONPATH=. python3 src/data/fetch_real_weather.py --start 20240601 --end 20240829

주의:
- serviceKey는 "일반 인증키(Decoding)" 값을 써야 한다. Encoding된 값을 넣으면 %2B 같은 문자가
  requests에서 이중 인코딩되어 오류가 날 수 있음.
- 지점번호(stnIds) 기본값 119 = 수원. 다른 지역 쓰려면 --station 옵션으로 변경.
  주요 지점: 서울108, 인천112, 수원119, 파주99, 이천203, 평택201
"""
import os
import time
from datetime import datetime, timedelta

import pandas as pd
import requests
from dotenv import load_dotenv

# 최상위 경로의 .env 파일에 모아둔 API 키들을 시스템에 불러옵니다.
load_dotenv()

ASOS_HOURLY_URL = "https://apis.data.go.kr/1360000/AsosHourlyInfoService/getWthrDataList"


def _get_service_key() -> str:
    # 환경변수에 로드된 키를 꺼내서 사용합니다.
    key = os.environ.get("WEATHER_API_KEY")
    if not key:
        raise RuntimeError("API 키가 설정되지 않았습니다. .env 파일을 확인하세요.")
    return key


def fetch_asos_hourly(
    start_dt: str,
    end_dt: str,
    station_id: str = "119",
    num_of_rows: int = 999,
    timeout: int = 10,
) -> pd.DataFrame:
    
    # 파이썬 환경변수나 디코딩 키를 쓰지 않고, 인코딩된 키를 직접 하드코딩합니다.
    ENCODED_KEY = "kDAOBXWkloTgzYhZT9Mf6MnNop1ew5A3z0FBFplKMR%2BF4H3liAuNsBNkrwpywkSAR3NaVGuGcy6bCayLfYN3GA%3D%3D"
    
    # URL에 키를 먼저 강제로 붙여버립니다.
    request_url = f"{ASOS_HOURLY_URL}?serviceKey={ENCODED_KEY}"

    all_rows = []
    page_no = 1

    while True:
        # params에서 serviceKey는 뺍니다. (requests가 건드리지 못하게 함)
        params = {
            "pageNo": page_no,
            "numOfRows": num_of_rows,
            "dataType": "JSON",
            "dataCd": "ASOS",
            "dateCd": "HR",
            "startDt": start_dt,
            "startHh": "00",
            "endDt": end_dt,
            "endHh": "23",
            "stnIds": station_id,
        }

        # 수정된 request_url로 요청을 보냅니다.
        resp = requests.get(request_url, params=params, timeout=timeout)
        resp.raise_for_status()

        try:
            data = resp.json()
        except ValueError:
            raise RuntimeError(f"응답이 JSON이 아닙니다. 응답 일부: {resp.text[:300]}")

        header = data.get("response", {}).get("header", {})
        result_code = header.get("resultCode")
        if result_code != "00":
            raise RuntimeError(f"API 오류 [{result_code}]: {header.get('resultMsg')}")

        body = data["response"]["body"]
        items = body.get("items", {}).get("item", [])
        if isinstance(items, dict):  
            items = [items]

        all_rows.extend(items)

        total_count = int(body.get("totalCount", 0))
        if page_no * num_of_rows >= total_count or not items:
            break
        page_no += 1
        time.sleep(0.2) 

    if not all_rows:
        raise RuntimeError("조회된 데이터가 없습니다.")

    df = pd.DataFrame(all_rows)
    df["timestamp"] = pd.to_datetime(df["tm"])
    df["outdoor_temp_c"] = pd.to_numeric(df["ta"], errors="coerce")
    df = df[["timestamp", "outdoor_temp_c"]].dropna().sort_values("timestamp").reset_index(drop=True)
    return df

def interpolate_to_interval(df: pd.DataFrame, interval_minutes: int = 5) -> pd.DataFrame:
    """1시간 간격 관측값을 지정된 간격(기본 5분)으로 선형보간."""
    df = df.set_index("timestamp").sort_index()
    new_index = pd.date_range(df.index.min(), df.index.max(), freq=f"{interval_minutes}min")
    df_interp = df.reindex(df.index.union(new_index)).interpolate(method="time").reindex(new_index)
    df_interp = df_interp.reset_index().rename(columns={"index": "timestamp"})
    return df_interp


if __name__ == "__main__":
    # 빠른 동작 확인용: 최근 3일
    end = datetime.now()
    start = end - timedelta(days=3)
    df = fetch_asos_hourly(start.strftime("%Y%m%d"), end.strftime("%Y%m%d"), station_id="119")
    print(df.head(10))
    print(f"\n총 {len(df)}행 (시간단위)")

    df_5min = interpolate_to_interval(df, 5)
    print(f"\n5분 간격 보간 후: {len(df_5min)}행")
    print(df_5min.head(10))
