"""
fetch_real_weather.py

configs/*.yaml 의 simulation.start_date + duration_days 기간에 맞춰
기상청 ASOS 실제 관측 기온을 받아와 5분 간격으로 보간하고
data/raw/real_weather_<station>_<start>_<end>.parquet 으로 캐시 저장.

실행 (PowerShell 예):
    $env:WEATHER_API_KEY="발급받은_인증키"
    PYTHONPATH=. python3 src/data/fetch_real_weather.py --config configs/base.yaml --station 119
"""
import argparse
import os
from datetime import datetime, timedelta

from src.config_loader import load_config
from src.data.weather_api import fetch_asos_hourly, interpolate_to_interval


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, default="configs/base.yaml")
    parser.add_argument("--station", type=str, default="119", help="기상청 지점번호 (기본 119=수원)")
    args = parser.parse_args()

    cfg = load_config(args.config)
    start = datetime.strptime(cfg.simulation.start_date, "%Y-%m-%d")
    end = start + timedelta(days=cfg.simulation.duration_days - 1)

    start_str = start.strftime("%Y%m%d")
    end_str = end.strftime("%Y%m%d")

    print(f"기상청 ASOS 조회: 지점 {args.station}, {start_str} ~ {end_str} ...")
    df_hourly = fetch_asos_hourly(start_str, end_str, station_id=args.station)
    print(f"시간단위 수신: {len(df_hourly)}행")

    df_interp = interpolate_to_interval(df_hourly, cfg.simulation.interval_minutes)
    print(f"{cfg.simulation.interval_minutes}분 간격 보간 후: {len(df_interp)}행")

    out_dir = cfg.raw_data_dir
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, f"real_weather_{args.station}_{start_str}_{end_str}.parquet")
    df_interp.to_parquet(out_path, index=False)

    print(f"\n저장 완료: {out_path}")
    missing = df_interp["outdoor_temp_c"].isna().sum()
    if missing > 0:
        print(f"⚠️ 결측치 {missing}건 있음 (기간 앞/뒤 경계 보간 실패 가능성, 확인 필요)")
    print(df_interp.describe())


if __name__ == "__main__":
    main()
