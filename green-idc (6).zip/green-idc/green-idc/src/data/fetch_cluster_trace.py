"""
fetch_cluster_trace.py

Google Cluster Trace 2019 (또는 Kaggle 샘플) CSV 데이터를 읽어와
시뮬레이션 간격(기본 5분)에 맞게 보간하고, IT 부하율(utilization) 캐시로 저장합니다.

실행 예시:
    PYTHONPATH=. python3 src/data/fetch_cluster_trace.py --csv data/raw/google_trace_sample.csv
"""
import argparse
import os
import pandas as pd
from datetime import datetime, timedelta

from src.config_loader import load_config

def process_cluster_trace(csv_path: str, interval_minutes: int, start_date: str) -> pd.DataFrame:
    print(f"CSV 읽는 중: {csv_path}")
    df = pd.read_csv(csv_path)
    
    # Kaggle 샘플의 컬럼명에 맞게 매핑 (필요시 수정)
    # 일반적으로 시간(초 또는 밀리초)과 CPU 사용량(%) 컬럼이 존재함
    time_col = df.columns[0]
    load_col = df.columns[1]
    
    # 임의의 기준일(시뮬레이션 시작일)부터 타임스탬프 생성
    base_time = pd.to_datetime(start_date)
    
    # 시간이 초(second) 단위로 기록되어 있다고 가정
    df['timestamp'] = base_time + pd.to_timedelta(df[time_col], unit='s')
    df['it_utilization'] = pd.to_numeric(df[load_col], errors='coerce')
    
    # 0~1 사이의 값으로 정규화 (만약 0~100 스케일이라면 100으로 나눔)
    if df['it_utilization'].max() > 1.0:
        df['it_utilization'] = df['it_utilization'] / 100.0
        
    # 최소 부하(0.15)와 최대 부하(0.95) 사이로 클리핑
    df['it_utilization'] = df['it_utilization'].clip(0.15, 0.95)
    
    df = df[['timestamp', 'it_utilization']].dropna().set_index('timestamp').sort_index()
    
    # 5분 간격으로 리샘플링 및 선형 보간
    new_index = pd.date_range(df.index.min(), df.index.max(), freq=f"{interval_minutes}min")
    df_interp = df.reindex(df.index.union(new_index)).interpolate(method="time").reindex(new_index)
    
    return df_interp.reset_index().rename(columns={"index": "timestamp"})

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, default="configs/base.yaml")
    parser.add_argument("--csv", type=str, required=True, help="Google Cluster Trace CSV 파일 경로")
    args = parser.parse_args()

    cfg = load_config(args.config)
    
    if not os.path.exists(args.csv):
        print(f"[오류] CSV 파일을 찾을 수 없습니다: {args.csv}")
        return
        
    df_interp = process_cluster_trace(args.csv, cfg.simulation.interval_minutes, cfg.simulation.start_date)
    
    out_dir = cfg.raw_data_dir
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "real_it_load.parquet")
    df_interp.to_parquet(out_path, index=False)
    
    print(f"\n저장 완료: {out_path}")
    print(df_interp.describe())

if __name__ == "__main__":
    main()