"""
validate_rule_based.py

과제 성능기준 검증:
- Rule-based 온도유지율(18~27도) >= 95%
- 위기시나리오(서버급증/냉각기고장/폭염) 상황에서도 서버온도 27도 이하 유지되는지

configs/ 아래 base.yaml + experiment_crisis_*.yaml 을 전부 돌려서
결과를 하나의 요약표(csv + 콘솔)로 만든다.

실행: PYTHONPATH=. python3 src/evaluation/validate_rule_based.py
"""
import glob
import os

import pandas as pd

from src.config_loader import load_config
from src.simulator.run_thermal_simulation import run_thermal_simulation

TEMP_MAINTAIN_TARGET_PCT = 95.0   # Rule-based 온도유지율 기준
CRISIS_MAX_TEMP_C = 27.0          # 위기시나리오에서도 지켜야 할 상한


def evaluate_config(config_path: str) -> dict:
    cfg = load_config(config_path)
    df = run_thermal_simulation(cfg)

    total = len(df)
    in_range = (~df["temp_violation"]).sum()
    maintain_rate_pct = in_range / total * 100

    max_temp = df["room_temp_c"].max()
    min_temp = df["room_temp_c"].min()
    max_unmet = df["unmet_load_kw"].max()

    is_crisis = "crisis" in cfg.experiment_name
    # 위기시나리오는 발생 구간(온도가 24도 기준선에서 벗어난 시점)만 따로 봐도 되지만,
    # 여기서는 보수적으로 전체 구간 기준 27도 초과 여부로 판정
    crisis_pass = (max_temp <= CRISIS_MAX_TEMP_C) if is_crisis else None

    return {
        "experiment": cfg.experiment_name,
        "config": os.path.basename(config_path),
        "steps": total,
        "maintain_rate_pct": round(maintain_rate_pct, 2),
        "maintain_pass(>=95%)": maintain_rate_pct >= TEMP_MAINTAIN_TARGET_PCT,
        "min_temp_c": round(min_temp, 2),
        "max_temp_c": round(max_temp, 2),
        "max_unmet_load_kw": round(max_unmet, 1),
        "crisis_scenario": is_crisis,
        "crisis_pass(<=27C)": crisis_pass,
    }


def main():
    config_paths = sorted(glob.glob("configs/base.yaml")) + sorted(
        glob.glob("configs/experiment_crisis_*.yaml")
    )

    results = []
    for path in config_paths:
        print(f"실행 중: {path} ...")
        results.append(evaluate_config(path))

    summary = pd.DataFrame(results)

    os.makedirs("results", exist_ok=True)
    out_path = "results/rule_based_validation.csv"
    summary.to_csv(out_path, index=False)

    print("\n" + "=" * 70)
    print("Rule-based 제어 성능기준 검증 결과")
    print("=" * 70)
    print(summary.to_string(index=False))
    print(f"\n저장됨: {out_path}")

    base_row = summary[summary["experiment"] == "base"].iloc[0]
    print(f"\n[기본 스펙] 온도유지율 {base_row['maintain_rate_pct']}% "
          f"({'PASS' if base_row['maintain_pass(>=95%)'] else 'FAIL'}, 기준 95%+)")

    crisis_rows = summary[summary["crisis_scenario"] == True]
    for _, row in crisis_rows.iterrows():
        status = "PASS" if row["crisis_pass(<=27C)"] else "FAIL"
        print(f"[{row['experiment']}] 최고온도 {row['max_temp_c']}C ({status}, 기준 <=27C)")


if __name__ == "__main__":
    main()
