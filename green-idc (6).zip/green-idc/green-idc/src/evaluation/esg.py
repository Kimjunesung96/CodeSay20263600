"""
esg.py
데이터센터의 ESG(환경, 사회, 지배구조) 지표를 계산합니다.
"""

def calculate_carbon_emission_tco2(energy_kwh: float) -> float:
    """
    전력 사용량(kWh)에 따른 탄소 배출량 계산 (tCO2)
    한국전력 2022년 기준 배출계수: 0.459 tCO2/MWh
    """
    energy_mwh = energy_kwh / 1000.0
    return energy_mwh * 0.459

def calculate_wue(water_usage_l: float, it_energy_kwh: float) -> float:
    """
    WUE (Water Usage Effectiveness) 계산
    물 사용량(L) / IT 전력량(kWh)
    """
    if it_energy_kwh <= 0:
        return 0.0
    return water_usage_l / it_energy_kwh

def estimate_chiller_water_usage_l(chiller_energy_kwh: float) -> float:
    """
    수랭식 냉각탑 증발량 추정 (임의 가설)
    칠러 1kWh 가동 시 약 1.8L의 물이 증발한다고 가정합니다.
    """
    return chiller_energy_kwh * 1.8