"""
compare_sinergym.py

Sinergym(EnergyPlus 기반 실제 검증된 시뮬레이터)에서 뽑은 로그(외기온, IT부하)를
우리 자체 물리엔진(room_dynamics.py)에 그대로 넣어서 돌리고, 두 결과(서버룸 온도
추세, 냉각모드 전환 시점)를 비교한다.

주의: Sinergym의 datacenter_dx 모델은 실제 EnergyPlus 건물 스케일(동/서 2존)이라
전력(kW) 절대값 자체는 우리 config(500서버, 칠러 250kW 등)와 스케일이 다르다.
그래서 절대 kW를 1:1로 맞추는 게 아니라, "같은 외기온이 들어왔을 때 온도가
안정적으로 유지되는 추세"와 "자연공조/칠러 전환 타이밍"이 얼마나 비슷한 패턴을
보이는지를 검증 지표로 삼는다.

실행:
    PYTHONPATH=. python3 src/evaluation/compare_sinergym.py --sinergym-csv sinergym_compare/sinergym_log.csv
"""
import argparse
import os

import numpy as np
import pandas as pd

from src.config_loader import load_config
from src.thermal_model.room_dynamics import step_room_dynamics


def run_our_engine(df_sinergym: pd.DataFrame, cfg, dt_seconds: int = 600) -> pd.DataFrame:
    """Sinergym 로그의 외기온/IT부하를 그대로 우리 엔진에 순서대로 먹인다."""
    room_temp = cfg.thermal.initial_room_temp_c
    rows = []

    for _, r in df_sinergym.iterrows():
        result = step_room_dynamics(
            room_temp_c=room_temp,
            outdoor_temp_c=float(r["outdoor_temp_c"]),
            utilization=float(r["it_utilization"]),
            dt_seconds=dt_seconds,
            num_servers=cfg.datacenter.num_servers,
            rated_power_per_server_kw=cfg.datacenter.rated_power_per_server_kw,
            airflow_m3_per_s=cfg.thermal.airflow_m3_per_s,
            air_density=cfg.thermal.air_density,
            specific_heat_air=cfg.thermal.specific_heat_air,
            room_thermal_mass_kj_per_c=cfg.thermal.room_thermal_mass_kj_per_c,
            free_cooling_threshold_c=cfg.cooling.free_cooling_threshold_c,
            mixed_mode_threshold_c=cfg.cooling.mixed_mode_threshold_c,
            chiller_cop_rated=cfg.cooling.chiller_cop_rated,
            chiller_cop_min=cfg.cooling.chiller_cop_min,
            cop_ref_outdoor_temp_c=cfg.cooling.cop_ref_outdoor_temp_c,
            chiller_max_capacity_kw=cfg.cooling.chiller_max_capacity_kw,
            target_temp_c=cfg.thermal.target_temp_c,
            temp_safety_min_c=cfg.thermal.temp_safety_min_c,
            temp_safety_max_c=cfg.thermal.temp_safety_max_c,
        )
        room_temp = result.room_temp_c
        rows.append({
            "step": r["step"],
            "our_room_temp_c": result.room_temp_c,
            "our_mode": result.mode,
            "our_total_power_kw": result.total_power_kw,
        })

    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sinergym-csv", type=str, default="sinergym_compare/sinergym_log.csv")
    parser.add_argument("--config", type=str, default="configs/base.yaml")
    args = parser.parse_args()

    if not os.path.exists(args.sinergym_csv):
        print(f"[오류] 파일이 없습니다: {args.sinergym_csv}")
        return

    df_sinergym = pd.read_csv(args.sinergym_csv)
    cfg = load_config(args.config)

    df_ours = run_our_engine(df_sinergym, cfg, dt_seconds=600)

    merged = df_sinergym.merge(df_ours, on="step")

    # ---- 온도 추세 비교 ----
    if merged["our_room_temp_c"].std() == 0:
        corr_temp = None
        corr_note = "우리 엔진 온도가 전 구간 고정값 -> 상관계수 계산불가 (아래 참고)"
    else:
        corr_temp = merged["room_temp_c"].corr(merged["our_room_temp_c"])
        corr_note = ""
    mean_abs_diff = (merged["room_temp_c"] - merged["our_room_temp_c"]).abs().mean()

    # ---- 냉각모드 전환 타이밍 비교 ----
    # Sinergym엔 명시적 "모드"가 없으니, 우리 쪽 자연공조/칠러 판정을
    # "외기온이 free_cooling_threshold보다 낮은가"로 다시 계산해서 일치율을 봄
    merged["expected_free_cooling"] = merged["outdoor_temp_c"] < cfg.cooling.free_cooling_threshold_c
    merged["our_is_free"] = merged["our_mode"] == "free"
    mode_agreement_pct = (merged["expected_free_cooling"] == merged["our_is_free"]).mean() * 100

    print("=" * 60)
    print("Sinergym(EnergyPlus) vs 자체 물리엔진 비교 결과")
    print("=" * 60)
    print(f"비교 스텝 수: {len(merged)}")
    if corr_temp is None:
        print(f"온도 추세 상관계수: 계산불가 - {corr_note}")
        print("  -> 우리 엔진은 냉각용량이 충분하면 목표온도로 '완벽하게' 수렴하는 이상적 제어기라,")
        print("     항상 정확히 target_temp_c로 고정됨. Sinergym은 실제 열관성/센서지연이 있어 계속 미세하게 흔들림.")
        print("     이건 버그가 아니라 우리 모델의 단순화(피드백 제어가 물리적으로 즉각적이라고 가정) 때문.")
    else:
        print(f"온도 추세 상관계수 (room_temp_c 기준): {corr_temp:.3f}  (1.0에 가까울수록 같은 패턴)")
    print(f"평균 온도 차이: {mean_abs_diff:.2f}°C  (절대 스케일이 달라 참고용)")
    print(f"자연공조 판정 일치율: {mode_agreement_pct:.1f}%")

    out_path = "sinergym_compare/comparison_result.csv"
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    merged.to_csv(out_path, index=False)
    print(f"\n상세 비교 데이터 저장: {out_path}")


if __name__ == "__main__":
    main()