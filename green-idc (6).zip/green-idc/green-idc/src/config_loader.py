"""
config_loader.py
configs/*.yaml 을 읽어서 코드에서 쓰기 편한 객체로 변환.
"""
from dataclasses import dataclass
import yaml


@dataclass
class DatacenterConfig:
    num_servers: int
    rated_power_per_server_kw: float
    min_it_utilization: float
    max_it_utilization: float


@dataclass
class ThermalConfig:
    target_temp_c: float
    temp_safety_min_c: float
    temp_safety_max_c: float
    specific_heat_air: float
    air_density: float
    airflow_m3_per_s: float
    room_thermal_mass_kj_per_c: float
    initial_room_temp_c: float


@dataclass
class CoolingConfig:
    free_cooling_threshold_c: float
    mixed_mode_threshold_c: float
    chiller_cop_rated: float
    chiller_cop_min: float
    cop_ref_outdoor_temp_c: float
    chiller_max_capacity_kw: float


@dataclass
class ServerSurgeScenario:
    enabled: bool
    utilization_multiplier: float


@dataclass
class ChillerFailureScenario:
    enabled: bool
    capacity_ratio: float
    start_hour: float
    duration_hours: float


@dataclass
class HeatwaveScenario:
    enabled: bool
    outdoor_temp_override_c: float
    start_hour: float
    duration_hours: float


@dataclass
class CrisisScenariosConfig:
    server_surge: ServerSurgeScenario
    chiller_failure: ChillerFailureScenario
    heatwave: HeatwaveScenario


@dataclass
class SimulationConfig:
    start_date: str
    duration_days: int
    interval_minutes: int
    weather_base_temp_c: float
    weather_daily_amplitude_c: float
    weather_seasonal_amplitude_c: float
    weather_noise_std_c: float


@dataclass
class AppConfig:
    experiment_name: str
    seed: int
    datacenter: DatacenterConfig
    thermal: ThermalConfig
    cooling: CoolingConfig
    simulation: SimulationConfig
    crisis: CrisisScenariosConfig
    raw_data_dir: str
    processed_data_dir: str
    results_dir: str


def load_config(path: str) -> AppConfig:
    with open(path, "r", encoding="utf-8") as f:
        raw = yaml.safe_load(f)

    crisis_raw = raw.get("crisis_scenarios", {})
    crisis = CrisisScenariosConfig(
        server_surge=ServerSurgeScenario(**crisis_raw.get(
            "server_surge", {"enabled": False, "utilization_multiplier": 1.0}
        )),
        chiller_failure=ChillerFailureScenario(**crisis_raw.get(
            "chiller_failure",
            {"enabled": False, "capacity_ratio": 1.0, "start_hour": 0, "duration_hours": 0},
        )),
        heatwave=HeatwaveScenario(**crisis_raw.get(
            "heatwave",
            {"enabled": False, "outdoor_temp_override_c": 35.0, "start_hour": 0, "duration_hours": 0},
        )),
    )

    return AppConfig(
        experiment_name=raw["experiment"]["name"],
        seed=raw["experiment"]["seed"],
        datacenter=DatacenterConfig(**raw["datacenter"]),
        thermal=ThermalConfig(**raw["thermal"]),
        cooling=CoolingConfig(**raw["cooling"]),
        simulation=SimulationConfig(**raw["simulation"]),
        crisis=crisis,
        raw_data_dir=raw["paths"]["raw_data_dir"],
        processed_data_dir=raw["paths"]["processed_data_dir"],
        results_dir=raw["paths"]["results_dir"],
    )


if __name__ == "__main__":
    cfg = load_config("configs/base.yaml")
    print(cfg)
