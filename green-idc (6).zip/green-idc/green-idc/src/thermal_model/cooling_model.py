"""
cooling_model.py

데이터센터 냉각 시스템의 핵심 물리 모델.
- IT 발열량(=IT 전력) 계산
- 자연공조(Free Cooling) 가능 여부 판단 및 용량 계산 (Q = m_dot * cp * dT)
- 칠러(기계식 냉각) COP 및 소비전력 계산
- PUE 계산

이 파일은 "직접 구현 필수" 파트이므로 외부 열역학 라이브러리를 쓰지 않고
기본 공식만으로 계산한다.
"""
from dataclasses import dataclass


@dataclass
class CoolingResult:
    it_power_kw: float          # IT 장비(서버) 소비 전력 = IT 발열량
    cooling_load_kw: float      # 제거해야 할 총 열량(kW)
    free_cooling_kw: float      # 자연공조로 처리한 열량
    chiller_load_kw: float      # 칠러가 처리해야 할 열량
    chiller_cop: float          # 해당 시점 칠러 COP
    chiller_power_kw: float     # 칠러 소비 전력
    cooling_power_kw: float     # 총 냉각 전력 (칠러 + 팬/펌프 등, 여기선 칠러만 취급)
    total_power_kw: float       # IT 전력 + 냉각 전력
    pue: float                  # Power Usage Effectiveness
    mode: str                   # "free" | "mixed" | "chiller"


def calc_it_power_kw(num_servers: int, rated_power_per_server_kw: float, utilization: float) -> float:
    """IT 부하율(0~1)에 따른 IT 전력(=발열량, kW). 서버는 곧 저항성 발열원이라고 가정."""
    utilization = max(0.0, min(1.0, utilization))
    return num_servers * rated_power_per_server_kw * utilization


def calc_free_cooling_capacity_kw(
    outdoor_temp_c: float,
    target_temp_c: float,
    airflow_m3_per_s: float,
    air_density: float,
    specific_heat_air: float,
) -> float:
    """
    자연공조로 제거 가능한 최대 열량.
    Q = m_dot * cp * dT
    m_dot(kg/s) = airflow(m^3/s) * density(kg/m^3)
    dT = target_temp - outdoor_temp (외기가 목표온도보다 낮을 때만 유효)
    """
    delta_t = target_temp_c - outdoor_temp_c
    if delta_t <= 0:
        return 0.0
    m_dot = airflow_m3_per_s * air_density
    q_kw = m_dot * specific_heat_air * delta_t  # kJ/s = kW
    return max(0.0, q_kw)


def calc_chiller_cop(
    outdoor_temp_c: float,
    cop_rated: float,
    cop_min: float,
    cop_ref_outdoor_temp_c: float,
    cop_ref_low_temp_c: float = 5.0,
) -> float:
    """
    외기온이 높을수록 칠러 효율(COP)이 떨어진다는 것을 선형 보간으로 근사.
    - outdoor_temp <= cop_ref_low_temp_c  -> COP = cop_rated
    - outdoor_temp >= cop_ref_outdoor_temp_c -> COP = cop_min
    - 그 사이는 선형 보간
    """
    if outdoor_temp_c <= cop_ref_low_temp_c:
        return cop_rated
    if outdoor_temp_c >= cop_ref_outdoor_temp_c:
        return cop_min

    ratio = (outdoor_temp_c - cop_ref_low_temp_c) / (cop_ref_outdoor_temp_c - cop_ref_low_temp_c)
    cop = cop_rated - ratio * (cop_rated - cop_min)
    return cop


def calc_chiller_power_kw(cooling_load_kw: float, cop: float) -> float:
    """칠러 소비 전력 = 처리해야 할 냉각부하 / COP"""
    if cop <= 0:
        return 0.0
    return cooling_load_kw / cop


def run_cooling_step(
    outdoor_temp_c: float,
    utilization: float,
    num_servers: int,
    rated_power_per_server_kw: float,
    target_temp_c: float,
    airflow_m3_per_s: float,
    air_density: float,
    specific_heat_air: float,
    free_cooling_threshold_c: float,
    mixed_mode_threshold_c: float,
    chiller_cop_rated: float,
    chiller_cop_min: float,
    cop_ref_outdoor_temp_c: float,
) -> CoolingResult:
    """
    한 시점(timestep)의 IT 부하 + 외기온을 받아서 냉각 전략을 결정하고
    전력/PUE를 계산한다.

    모드 분기:
    - outdoor_temp <= free_cooling_threshold: 자연공조만으로 전량 처리 (mode="free")
    - free_cooling_threshold < outdoor_temp <= mixed_mode_threshold: 자연공조로 최대한 처리하고
      나머지는 칠러 (mode="mixed")
    - outdoor_temp > mixed_mode_threshold: 자연공조 기여 없음, 칠러 풀가동 (mode="chiller")
    """
    it_power_kw = calc_it_power_kw(num_servers, rated_power_per_server_kw, utilization)
    cooling_load_kw = it_power_kw  # 정상상태 가정: 제거해야 할 열량 = IT 발열량

    free_cap_kw = calc_free_cooling_capacity_kw(
        outdoor_temp_c, target_temp_c, airflow_m3_per_s, air_density, specific_heat_air
    )

    if outdoor_temp_c <= free_cooling_threshold_c:
        mode = "free"
        free_cooling_kw = min(cooling_load_kw, free_cap_kw)
        chiller_load_kw = max(0.0, cooling_load_kw - free_cooling_kw)
    elif outdoor_temp_c <= mixed_mode_threshold_c:
        mode = "mixed"
        free_cooling_kw = min(cooling_load_kw, free_cap_kw)
        chiller_load_kw = max(0.0, cooling_load_kw - free_cooling_kw)
    else:
        mode = "chiller"
        free_cooling_kw = 0.0
        chiller_load_kw = cooling_load_kw

    chiller_cop = calc_chiller_cop(
        outdoor_temp_c, chiller_cop_rated, chiller_cop_min, cop_ref_outdoor_temp_c
    )
    chiller_power_kw = calc_chiller_power_kw(chiller_load_kw, chiller_cop)

    cooling_power_kw = chiller_power_kw  # 팬/펌프 등 보조전력은 이후 확장 가능
    total_power_kw = it_power_kw + cooling_power_kw
    pue = total_power_kw / it_power_kw if it_power_kw > 0 else float("nan")

    return CoolingResult(
        it_power_kw=it_power_kw,
        cooling_load_kw=cooling_load_kw,
        free_cooling_kw=free_cooling_kw,
        chiller_load_kw=chiller_load_kw,
        chiller_cop=chiller_cop,
        chiller_power_kw=chiller_power_kw,
        cooling_power_kw=cooling_power_kw,
        total_power_kw=total_power_kw,
        pue=pue,
        mode=mode,
    )


if __name__ == "__main__":
    # 빠른 동작 확인 (더운 날 vs 추운 날)
    common = dict(
        num_servers=500,
        rated_power_per_server_kw=0.4,
        target_temp_c=24.0,
        airflow_m3_per_s=25.0,
        air_density=1.2,
        specific_heat_air=1.005,
        free_cooling_threshold_c=15.0,
        mixed_mode_threshold_c=22.0,
        chiller_cop_rated=4.3,
        chiller_cop_min=2.8,
        cop_ref_outdoor_temp_c=35.0,
    )

    hot = run_cooling_step(outdoor_temp_c=32.0, utilization=0.8, **common)
    cold = run_cooling_step(outdoor_temp_c=5.0, utilization=0.8, **common)

    print("더운 날(32C):", hot)
    print("추운 날(5C):", cold)
