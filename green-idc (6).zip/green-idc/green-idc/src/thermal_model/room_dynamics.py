"""
room_dynamics.py

기존 cooling_model.py는 "냉각이 항상 완벽히 처리된다"고 가정했지만,
실제로는 칠러 최대용량이 있고, 그걸 넘는 발열은 즉시 제거되지 못하고
서버룸 온도를 끌어올린다. 위기시나리오(냉각기 고장/폭염/서버급증)에서
27도 임계값을 넘는지 검증하려면 이 동역학이 필요하다.

에너지 보존식:
    C(kJ/°C) * dT/dt = Q_generated(kW) - Q_removed(kW)
    (1kW = 1kJ/s 이므로 단위 그대로 사용 가능)

다음 스텝 온도:
    T_new = T_old + (Q_gen - Q_removed) * dt_seconds / C
"""
from dataclasses import dataclass

from src.thermal_model.cooling_model import (
    calc_it_power_kw,
    calc_free_cooling_capacity_kw,
    calc_chiller_cop,
)


@dataclass
class RoomStepResult:
    room_temp_c: float          # 이번 스텝 종료 시점 서버룸 온도
    it_power_kw: float
    heat_load_kw: float         # 제거해야 할 발열량 (= it_power)
    free_cooling_kw: float      # 실제로 자연공조가 제거한 열량
    chiller_load_requested_kw: float  # 칠러에 요청된 부하
    chiller_power_kw: float
    chiller_cop: float
    cooling_supplied_kw: float  # 실제로 제거된 총 열량 (용량 한계 반영)
    unmet_load_kw: float        # 처리 못한 초과 발열 (용량 부족분)
    total_power_kw: float
    pue: float
    mode: str
    temp_violation: bool        # 안전범위(temp_safety) 벗어났는지


def determine_mode(outdoor_temp_c: float, free_threshold: float, mixed_threshold: float) -> str:
    if outdoor_temp_c <= free_threshold:
        return "free"
    if outdoor_temp_c <= mixed_threshold:
        return "mixed"
    return "chiller"


def step_room_dynamics(
    room_temp_c: float,
    outdoor_temp_c: float,
    utilization: float,
    dt_seconds: float,
    num_servers: int,
    rated_power_per_server_kw: float,
    airflow_m3_per_s: float,
    air_density: float,
    specific_heat_air: float,
    room_thermal_mass_kj_per_c: float,
    free_cooling_threshold_c: float,
    mixed_mode_threshold_c: float,
    chiller_cop_rated: float,
    chiller_cop_min: float,
    cop_ref_outdoor_temp_c: float,
    chiller_max_capacity_kw: float,
    target_temp_c: float = 24.0,
    chiller_capacity_ratio: float = 1.0,   # 1.0=정상, 0.0=완전고장, 0.5=반토막(위기시나리오용)
    temp_safety_min_c: float = 18.0,
    temp_safety_max_c: float = 27.0,
) -> RoomStepResult:
    """
    한 스텝(dt_seconds) 동안 서버룸 온도가 어떻게 변하는지 계산.
    이전 스텝의 room_temp_c를 입력으로 받아 다음 상태를 리턴하는 상태 전이 함수.

    제어 로직: 단순히 "그 순간 발열량만 제거"하는 게 아니라, 냉각 시스템이
    목표온도(target_temp_c)로 되돌아가려는 피드백 제어를 한다고 가정.
    즉 이번 스텝에 제거하고 싶은 열량 = 발열량 + (현재온도-목표온도)를 이번 스텝에
    보정하는 데 필요한 열량. 이렇게 해야 한번 온도가 튀어도(위기시나리오) 여유 용량이
    있으면 다시 목표온도로 돌아올 수 있다. 실제 제거량은 물리적 용량(자연공조+칠러)을
    넘을 수 없다.
    """
    it_power_kw = calc_it_power_kw(num_servers, rated_power_per_server_kw, utilization)
    heat_load_kw = it_power_kw

    mode = determine_mode(outdoor_temp_c, free_cooling_threshold_c, mixed_mode_threshold_c)

    # 자연공조 최대 용량 (현재 실제 룸 온도 기준, 발열량에 캡을 걸지 않음 -> 초과열도 회수 가능)
    free_cap_kw = max(0.0, calc_free_cooling_capacity_kw(
        outdoor_temp_c, room_temp_c, airflow_m3_per_s, air_density, specific_heat_air
    ))
    free_available_kw = 0.0 if mode == "chiller" else free_cap_kw

    chiller_cop = calc_chiller_cop(
        outdoor_temp_c, chiller_cop_rated, chiller_cop_min, cop_ref_outdoor_temp_c
    )
    # 위기시나리오(고장)로 인한 유효 최대용량
    chiller_available_kw = chiller_max_capacity_kw * max(0.0, min(1.0, chiller_capacity_ratio))

    total_available_kw = free_available_kw + chiller_available_kw

    # 목표온도로 되돌리기 위해 이번 스텝에 "제거하고 싶은" 열량 (음수면 이미 목표 이하 -> 발열량만 제거)
    correction_kw = (room_temp_c - target_temp_c) * room_thermal_mass_kj_per_c / dt_seconds
    desired_removal_kw = max(0.0, heat_load_kw + correction_kw)

    cooling_supplied_kw = min(desired_removal_kw, total_available_kw)

    # 자연공조 먼저 채우고, 나머지를 칠러가 담당
    free_cooling_kw = min(free_available_kw, cooling_supplied_kw)
    chiller_supplied_kw = max(0.0, cooling_supplied_kw - free_cooling_kw)

    chiller_load_requested_kw = max(0.0, heat_load_kw - free_cooling_kw)
    chiller_power_kw = chiller_supplied_kw / chiller_cop if chiller_cop > 0 else 0.0

    # 실제 발열량 대비 처리 못한 부분 (안전성 리포팅용)
    unmet_load_kw = max(0.0, heat_load_kw - cooling_supplied_kw)

    # 에너지 보존: 발열량 - 실제 제거된 열량 = 룸에 축적되는 순열량
    net_kw = heat_load_kw - cooling_supplied_kw
    delta_t = net_kw * dt_seconds / room_thermal_mass_kj_per_c
    new_room_temp_c = room_temp_c + delta_t

    total_power_kw = it_power_kw + chiller_power_kw
    pue = total_power_kw / it_power_kw if it_power_kw > 0 else float("nan")

    temp_violation = not (temp_safety_min_c <= new_room_temp_c <= temp_safety_max_c)

    return RoomStepResult(
        room_temp_c=new_room_temp_c,
        it_power_kw=it_power_kw,
        heat_load_kw=heat_load_kw,
        free_cooling_kw=free_cooling_kw,
        chiller_load_requested_kw=chiller_load_requested_kw,
        chiller_power_kw=chiller_power_kw,
        chiller_cop=chiller_cop,
        cooling_supplied_kw=cooling_supplied_kw,
        unmet_load_kw=unmet_load_kw,
        total_power_kw=total_power_kw,
        pue=pue,
        mode=mode,
        temp_violation=temp_violation,
    )


if __name__ == "__main__":
    # 정상 상황: 칠러 용량 충분 -> 온도 안정적으로 유지되는지 확인
    common = dict(
        num_servers=500,
        rated_power_per_server_kw=0.4,
        airflow_m3_per_s=25.0,
        air_density=1.2,
        specific_heat_air=1.005,
        room_thermal_mass_kj_per_c=45000.0,
        free_cooling_threshold_c=15.0,
        mixed_mode_threshold_c=22.0,
        chiller_cop_rated=4.3,
        chiller_cop_min=2.8,
        cop_ref_outdoor_temp_c=38.0,
        chiller_max_capacity_kw=250.0,
        target_temp_c=24.0,
    )

    print("=== 정상 상황 (외기 32도, 5분 간격 12스텝 = 1시간) ===")
    temp = 24.0
    for i in range(12):
        r = step_room_dynamics(
            room_temp_c=temp, outdoor_temp_c=32.0, utilization=0.8,
            dt_seconds=300, chiller_capacity_ratio=1.0, **common,
        )
        temp = r.room_temp_c
        print(f"step {i+1}: temp={temp:.3f}C mode={r.mode} unmet={r.unmet_load_kw:.1f}kW pue={r.pue:.3f}")

    print("\n=== 위기: 칠러 완전고장(capacity_ratio=0) + 폭염 39도, 1시간 ===")
    temp = 24.0
    for i in range(12):
        r = step_room_dynamics(
            room_temp_c=temp, outdoor_temp_c=39.0, utilization=0.9,
            dt_seconds=300, chiller_capacity_ratio=0.0, **common,
        )
        temp = r.room_temp_c
        print(f"step {i+1}: temp={temp:.3f}C mode={r.mode} unmet={r.unmet_load_kw:.1f}kW violation={r.temp_violation}")
