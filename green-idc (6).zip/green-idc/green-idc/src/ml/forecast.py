"""
forecast.py
LightGBM 모델을 사용하여 미래 외기온과 IT 부하를 예측하는 ML 엔진입니다.
"""
import os
import glob
import pandas as pd
import joblib
import warnings

# LightGBM 경고 무시
warnings.filterwarnings("ignore", category=UserWarning)

def run_lgbm_forecast(current_timestamp_str: str, lookahead_steps: int):
    """
    현재 시간부터 lookahead_steps 만큼의 미래를 예측합니다.
    """
    MODELS_DIR = "models"
    
    # 훈련된 모델 찾기 (대시보드 또는 train.py에서 생성한 모델)
    temp_models = glob.glob(f"{MODELS_DIR}/*outdoor_temp_c.pkl")
    util_models = glob.glob(f"{MODELS_DIR}/*it_utilization.pkl")
    
    if not temp_models or not util_models:
        # 모델이 아직 없으면 더미 데이터 반환 (에러 방지)
        return [25.0] * lookahead_steps, [0.5] * lookahead_steps
        
    # 가장 최근에 생성된(또는 기본) 모델 로드
    model_temp = joblib.load(temp_models[-1])
    model_util = joblib.load(util_models[-1])
    
    # 예측용 미래 시계열 데이터프레임 생성
    start_time = pd.to_datetime(current_timestamp_str)
    # 현재 시간 이후의 스텝부터 예측 (freq="5min")
    future_times = pd.date_range(start=start_time, periods=lookahead_steps, freq="5min")
    
    df_future = pd.DataFrame({'timestamp': future_times})
    df_future['hour'] = df_future['timestamp'].dt.hour + df_future['timestamp'].dt.minute / 60.0
    df_future['dayofweek'] = df_future['timestamp'].dt.dayofweek
    df_future['dayofyear'] = df_future['timestamp'].dt.dayofyear
    
    features = ['hour', 'dayofweek', 'dayofyear']
    
    # 모델 예측 수행
    pred_temps = model_temp.predict(df_future[features]).tolist()
    pred_utils = model_util.predict(df_future[features]).tolist()
    
    return pred_temps, pred_utils

if __name__ == "__main__":
    # 단독 실행 테스트용
    temps, utils = run_lgbm_forecast("2024-09-15 12:00:00", 6)
    print(f"예측 외기온: {temps}")
    print(f"예측 부하율: {utils}")