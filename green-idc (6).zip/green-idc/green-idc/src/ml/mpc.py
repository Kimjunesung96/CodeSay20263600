"""
mpc.py (v2 - 진짜 MPC)

기존 버전은 "현재 시점 하나만 보고" 목표온도를 grid search하는 순간(greedy)
최적화였다. MPC(Model Predictive Control)의 핵심은 "미래를 예측하고, 그
예측 경로 전체에 대해 비용이 최소가 되는 행동을 고른 뒤, 그중 첫 스텝만
실행하고 다음 스텝에서 다시 계획을 세우는 것"(receding horizon)이다.

이번 버전은:
1. src/ml/forecast.py 의 학습된 LightGBM 모델로 향후 HORIZON_STEPS 만큼
   외기온/IT부하를 예측한다.
2. 후보 목표온도(20~26도) 각각에 대해, 그 예측 경로 전체를 room_dynamics로
   롤아웃(rollout)해서 누적 비용(전력 총량 + 위반 페널티)을 계산한다.
3. 누적 비용이 가장 낮은 후보를 선택하고, "현재 시점"에 대한 그 후보의
   결과값을 반환한다 (다음 호출 때 새로 예측해서 다시 계획하는 구조이므로
   여기서는 첫 스텝 결과만 쓰면 됨 = receding horizon).

예측모델(models/*.pkl)이 없으면, "지금 값이 계속 유지된다"고 가정하는
persistence 예측으로 안전하게 폴백한다 (완전히 죽지 않도록).
"""
from datetime import datetime

import numpy as np

from src.config_loader import load_config
from src.thermal_model.room_dynamics import step_room_dynamics

cfg = load_config("configs/base.yaml")

HORIZON_STEPS = 6       # 5분 간격 x 6 = 30분 앞을 내다봄
DT_SECONDS = 300        # 5분 간격 (forecast.py의 future_times 간격과 일치해야 함)

try:
    from src.ml.forecast import run_lgbm_forecast
    _HAS_FORECAST = True
except ImportError:
    _HAS_FORECAST = False


def _get_forecast(current_room_outdoor_temp_c: float, current_it_utilization: float,
                   current_timestamp_str: str | None):
    """예측모델이 있으면 그걸 쓰고, 없으면 '지금 값 유지' 폴백."""
    if _HAS_FORECAST:
        ts = current_timestamp_str or datetime.now().strftime("%Y-%m-%d %H:%M:00")
        temps, utils = run_lgbm_forecast(ts, HORIZON_STEPS)
        # 예측모델이 로드 실패해서 더미(25.0 고정) 리턴하는 경우도 있으니
        # 그 경우엔 그냥 persistence로 대체
        if all(abs(t - 25.0) < 1e-6 for t in temps) and all(abs(u - 0.5) < 1e-6 for u in utils):
            pass  # 아래 폴백으로 흘려보냄
        else:
            return temps, utils

    # 폴백: 지금 값이 그대로 유지된다고 가정 (persistence forecast)
    return (
        [current_room_outdoor_temp_c] * HORIZON_STEPS,
        [current_it_utilization] * HORIZON_STEPS,
    )


def _rollout_cost(start_room_temp_c: float, target_temp_c: float,
                   forecast_temps: list, forecast_utils: list) -> tuple:
    """target_temp_c로 고정했을 때, 예측된 미래 경로 전체를 굴려서 누적비용과 첫 스텝 결과를 리턴."""
    room_temp = start_room_temp_c
    total_cost = 0.0
    first_step_result = None

    for i, (t_out, util) in enumerate(zip(forecast_temps, forecast_utils)):
        res = step_room_dynamics(
            room_temp_c=room_temp,
            outdoor_temp_c=t_out,
            utilization=util,
            dt_seconds=DT_SECONDS,
            num_servers=cfg.datacenter.num_servers,
            rated_power_per_server_kw=cfg.datacenter.rated_power_per_server_kw,
            airflow_m3_per_s=cfg.thermal.airflow_m3_per_s,
            air_density=cfg.thermal.air_density,
            specific_heat_air=cfg.thermal.specific_heat_air,
            room_thermal_mass_kj_per_c=cfg.thermal.room_thermal_mass_kj_per_c,
            free_cooling_threshold_c=cfg.cooling.free_cooling_threshold_c,
            mixed_mode_threshold_c=cfg.cooling.mixed_mode_threshold_c,
            chiller_cop_rated=cfg.cooling.chiller_cop_rated,
            chiller_cop_min=cfg.cooling.chiller_cop_min,
            cop_ref_outdoor_temp_c=cfg.cooling.cop_ref_outdoor_temp_c,
            chiller_max_capacity_kw=cfg.cooling.chiller_max_capacity_kw,
            target_temp_c=target_temp_c,
            temp_safety_min_c=cfg.thermal.temp_safety_min_c,
            temp_safety_max_c=cfg.thermal.temp_safety_max_c,
        )

        step_cost = res.total_power_kw
        if res.temp_violation:
            step_cost += 999999.0
        # 미래로 갈수록 예측 신뢰도가 낮아지니 먼 미래 비용은 살짝 덜 반영 (할인율)
        discount = 0.9 ** i
        total_cost += step_cost * discount

        if i == 0:
            first_step_result = res

        room_temp = res.room_temp_c

    # 기준 목표온도(24도)에서 너무 멀어지는 걸 살짝 억제 (불필요한 출렁임 방지)
    total_cost += abs(target_temp_c - cfg.thermal.target_temp_c) * 0.1

    return total_cost, first_step_result


def run_rl_mpc(current_room_temp_c: float, current_outdoor_temp_c: float,
               current_it_utilization: float, current_timestamp_str: str | None = None):
    """
    [진짜 MPC] 미래 HORIZON_STEPS(기본 30분)를 예측모델로 내다보고,
    그 예측 경로 전체에서 누적비용이 최소인 목표온도를 찾은 뒤,
    '지금 이 순간'에 대한 결과만 반환한다 (receding horizon).
    """
    forecast_temps, forecast_utils = _get_forecast(
        current_outdoor_temp_c, current_it_utilization, current_timestamp_str
    )

    best_cost = float("inf")
    best_result = None

    for candidate_target in np.arange(20.0, 26.5, 0.5):
        cost, first_step_result = _rollout_cost(
            current_room_temp_c, float(candidate_target), forecast_temps, forecast_utils
        )
        if cost < best_cost:
            best_cost = cost
            best_result = first_step_result

    valid_pue = best_result.pue if best_result.pue == best_result.pue else 0.0

    return (
        best_result.mode,
        best_result.chiller_power_kw,
        best_result.room_temp_c,
        valid_pue,
        best_result.temp_violation,
    )


if __name__ == "__main__":
    # 빠른 동작 확인
    mode, power, temp, pue, viol = run_rl_mpc(
        current_room_temp_c=24.0, current_outdoor_temp_c=32.0, current_it_utilization=0.8
    )
    print(f"모드={mode}, 칠러전력={power:.2f}kW, 예상온도={temp:.2f}C, PUE={pue:.3f}, 위반={viol}")
    print(f"예측모델 감지됨: {_HAS_FORECAST}")