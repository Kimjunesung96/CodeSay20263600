import os
import pandas as pd
import lightgbm as lgb
import joblib
from sklearn.metrics import mean_absolute_percentage_error

def train_models():
    # 1. 시계열 데이터 로드
    data_path = "data/processed/base/timeseries.parquet"
    if not os.path.exists(data_path):
        print(f"❌ 데이터 파일이 없습니다. 먼저 시뮬레이터를 실행해주세요: {data_path}")
        return

    print("데이터 로딩 중...")
    df = pd.read_parquet(data_path)
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    
    # 2. 특징(Feature) 추출: 시계열의 주기성을 잡기 위해 시간 기반 피처 생성
    df['hour'] = df['timestamp'].dt.hour + df['timestamp'].dt.minute / 60.0
    df['dayofweek'] = df['timestamp'].dt.dayofweek
    df['dayofyear'] = df['timestamp'].dt.dayofyear

    # 예측에 사용할 특징과 예측할 타겟 변수
    features = ['hour', 'dayofweek', 'dayofyear']
    targets = ['outdoor_temp_c', 'it_utilization']

    X = df[features]
    
    # 모델 저장 폴더 생성
    os.makedirs("models", exist_ok=True)

    # 3. 타겟별로 LightGBM 모델 학습
    for target in targets:
        y = df[target]
        
        # 모델 정의 및 학습 (과제 스펙 MAPE 5~8% 이내 달성을 위한 기본 세팅)
        model = lgb.LGBMRegressor(n_estimators=100, random_state=42)
        model.fit(X, y)
        
        # 모델 저장
        model_path = f"models/lgbm_{target}.pkl"
        joblib.dump(model, model_path)
        
        # 오차율(MAPE) 확인
        preds = model.predict(X)
        mape = mean_absolute_percentage_error(y, preds) * 100
        print(f"✅ [{target}] 학습 완료! 저장 위치: {model_path} (오차율 MAPE: {mape:.2f}%)")

if __name__ == "__main__":
    train_models()