import os
import logging
from datetime import datetime, timedelta
from typing import List, Optional

import numpy as np
import pandas as pd
import uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from src.config_loader import load_config
from src.thermal_model.room_dynamics import step_room_dynamics
from src.data.weather_api import fetch_asos_hourly

# 로깅 설정 (서버 터미널에 상태를 출력하기 위함)
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ==========================================
# 0. 미래에 추가될 AI 모델 자동 감지 (플러그앤플레이 방식)
# ==========================================
try:
    from src.ml.forecast import run_lgbm_forecast
    HAS_FORECAST_MODEL = True
    logger.info("✅ 예측 모델(LightGBM) 감지 완료. API에 연결합니다.")
except ImportError:
    HAS_FORECAST_MODEL = False
    logger.warning("⚠️ 예측 모델을 찾을 수 없습니다. 기본(Dummy) 로직으로 우회합니다.")

try:
    from src.ml.mpc import run_rl_mpc
    HAS_MPC_MODEL = True
    logger.info("✅ 최적화 제어 모델(MPC/RL) 감지 완료. API에 연결합니다.")
except ImportError:
    HAS_MPC_MODEL = False
    logger.warning("⚠️ MPC 모델을 찾을 수 없습니다. 물리 엔진(Rule-based)으로 대체합니다.")


app = FastAPI(title="Green IDC API", description="데이터센터 지능형 냉각/전력 최적화 API", version="1.0.0")

# 서버 구동 시 환경설정 로드
cfg = load_config("configs/base.yaml")

# ==========================================
# 1. 데이터 입출력 스키마 (Pydantic)
# ==========================================
class ForecastRequest(BaseModel):
    timestamp: str
    lookahead_steps: int = 12

class ForecastResponse(BaseModel):
    predicted_outdoor_temp_c: List[float]
    predicted_it_utilization: List[float]
    source: str  # 데이터 출처 (ai_model 또는 dummy_fallback)

class ControlRequest(BaseModel):
    current_room_temp_c: float
    current_outdoor_temp_c: float
    current_it_utilization: float

class ControlResponse(BaseModel):
    recommended_mode: str
    target_chiller_power_kw: float
    expected_room_temp_c: float
    pue: float
    temp_violation: bool
    source: str  # 로직 출처 (rule_based 또는 mpc_rl)

class RolloutRequest(BaseModel):
    config_name: str = "base"
    horizon_hours: int = 24
    current_room_temp_c: float | None = None
    strategy: str = "rule_based"  # "rule_based" 또는 "mpc"

class RolloutPoint(BaseModel):
    timestamp: str
    outdoor_temp_c: float
    it_utilization: float
    mode: str
    room_temp_c: float
    pue: float
    temp_violation: bool
    chiller_capacity_ratio: float

class RolloutResponse(BaseModel):
    config_name: str
    horizon_hours: int
    strategy: str
    expected_avg_pue: float
    expected_max_temp_c: float
    temp_violation_count: int
    settings: List[RolloutPoint]

# ==========================================
# 2. API 엔드포인트
# ==========================================
@app.get("/health")
def health_check():
    return {"status": "ok", "message": "Green IDC API is running."}

@app.post("/forecast", response_model=ForecastResponse)
def get_forecast(req: ForecastRequest):
    """
    [자동 감지] src/ml/forecast.py 파일이 생기면 자동으로 AI 예측을 수행합니다.
    """
    if HAS_FORECAST_MODEL:
        temps, utils = run_lgbm_forecast(req.timestamp, req.lookahead_steps)
        return ForecastResponse(
            predicted_outdoor_temp_c=temps,
            predicted_it_utilization=utils,
            source="ai_model"
        )
    
    # 모델 파일이 없을 경우 작동하는 기본 우회 로직
    return ForecastResponse(
        predicted_outdoor_temp_c=[25.0] * req.lookahead_steps,
        predicted_it_utilization=[0.5] * req.lookahead_steps,
        source="dummy_fallback"
    )

@app.post("/control/optimize", response_model=ControlResponse)
def control_optimize(req: ControlRequest):
    """
    [Rule-based] 이미 완성된 물리 엔진을 사용하여 최적화 값을 반환합니다.
    """
    dt_seconds = 300 
    result = step_room_dynamics(
        room_temp_c=req.current_room_temp_c,
        outdoor_temp_c=req.current_outdoor_temp_c,
        utilization=req.current_it_utilization,
        dt_seconds=dt_seconds,
        num_servers=cfg.datacenter.num_servers,
        rated_power_per_server_kw=cfg.datacenter.rated_power_per_server_kw,
        airflow_m3_per_s=cfg.thermal.airflow_m3_per_s,
        air_density=cfg.thermal.air_density,
        specific_heat_air=cfg.thermal.specific_heat_air,
        room_thermal_mass_kj_per_c=cfg.thermal.room_thermal_mass_kj_per_c,
        free_cooling_threshold_c=cfg.cooling.free_cooling_threshold_c,
        mixed_mode_threshold_c=cfg.cooling.mixed_mode_threshold_c,
        chiller_cop_rated=cfg.cooling.chiller_cop_rated,
        chiller_cop_min=cfg.cooling.chiller_cop_min,
        cop_ref_outdoor_temp_c=cfg.cooling.cop_ref_outdoor_temp_c,
        chiller_max_capacity_kw=cfg.cooling.chiller_max_capacity_kw,
        target_temp_c=cfg.thermal.target_temp_c,
        temp_safety_min_c=cfg.thermal.temp_safety_min_c,
        temp_safety_max_c=cfg.thermal.temp_safety_max_c,
    )

    valid_pue = result.pue if result.pue == result.pue else 0.0

    return ControlResponse(
        recommended_mode=result.mode,
        target_chiller_power_kw=round(result.chiller_power_kw, 2),
        expected_room_temp_c=round(result.room_temp_c, 2),
        pue=round(valid_pue, 3),
        temp_violation=result.temp_violation,
        source="rule_based"
    )

@app.post("/control/mpc", response_model=ControlResponse)
def control_mpc(req: ControlRequest):
    """
    [자동 감지] src/ml/mpc.py 파일이 생기면 자동으로 강화학습 제어를 수행합니다.
    없을 경우 위에서 만든 Rule-based 물리 엔진 결과로 안전하게 대체합니다.
    """
    if HAS_MPC_MODEL:
        mode, power, temp, pue, viol = run_rl_mpc(req.current_room_temp_c, req.current_outdoor_temp_c, req.current_it_utilization)
        return ControlResponse(
            recommended_mode=mode,
            target_chiller_power_kw=round(power, 2),
            expected_room_temp_c=round(temp, 2),
            pue=round(pue, 3),
            temp_violation=viol,
            source="mpc_rl"
        )
    
    # 모델 파일이 없을 경우 물리 엔진 함수를 재사용하여 응답
    return control_optimize(req)
@app.get("/weather/current")
def get_current_weather():
    """기상청 API를 호출하여 현재 서울(108)의 최신 외기온을 반환합니다."""
    try:
        # 최근 2일치 데이터를 조회하여 가장 마지막 관측값을 가져옵니다.
        end_dt = datetime.now()
        start_dt = end_dt - timedelta(days=1)
        
        # 지점번호 108: 서울
        df = fetch_asos_hourly(start_dt.strftime("%Y%m%d"), end_dt.strftime("%Y%m%d"), station_id="108")
        
        if not df.empty:
            latest_temp = df.iloc[-1]['outdoor_temp_c']
            return {"station": "108 (Seoul)", "current_outdoor_temp_c": latest_temp}
        return {"error": "No data found"}
    except Exception as e:
        return {"error": str(e)}
@app.post("/control/rollout", response_model=RolloutResponse)
def control_rollout(req: RolloutRequest):
    """
    config_name(위기시나리오 포함)+horizon_hours 기준으로 미래를 롤아웃해서
    "위기 상황에서도 27도 이하를 유지하는지" 시계열로 검증하는 엔드포인트.
    strategy="rule_based"면 물리엔진 그대로, "mpc"면 매 스텝 run_rl_mpc로 목표온도를 다시 계산.
    (src/api/routers/control.py의 _rollout 로직을 여기로 흡수 + 위기시나리오 반영)
    """
    try:
        rollout_cfg = load_config(f"configs/{req.config_name}.yaml")
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail=f"config '{req.config_name}' not found")

    from src.simulator.generate_dataset import (
        generate_weather_series, generate_utilization_series,
        try_load_real_weather, try_load_real_utilization,
    )
    from src.simulator.run_thermal_simulation import apply_crisis_scenarios

    rng = np.random.default_rng(rollout_cfg.seed)
    interval_min = rollout_cfg.simulation.interval_minutes
    periods = int(req.horizon_hours * 60 / interval_min)
    dt_seconds = interval_min * 60

    start = datetime.utcnow().replace(minute=0, second=0, microsecond=0)
    timestamps = pd.date_range(start=start, periods=periods, freq=f"{interval_min}min")

    outdoor_temp = try_load_real_weather(rollout_cfg, timestamps)
    if outdoor_temp is None:
        outdoor_temp = generate_weather_series(timestamps, rollout_cfg.simulation, rng)
    utilization = try_load_real_utilization(rollout_cfg, timestamps)
    if utilization is None:
        utilization = generate_utilization_series(timestamps, rollout_cfg.datacenter, rng)

    room_temp = req.current_room_temp_c if req.current_room_temp_c is not None else rollout_cfg.thermal.initial_room_temp_c

    settings = []
    for i, ts in enumerate(timestamps):
        hour_index = i * interval_min / 60.0
        mod_temp, mod_util, chiller_ratio = apply_crisis_scenarios(
            hour_index, float(outdoor_temp[i]), float(utilization[i]), rollout_cfg
        )

        if req.strategy == "mpc" and HAS_MPC_MODEL:
            mode, chiller_power, next_room_temp, pue, viol = run_rl_mpc(
                room_temp, mod_temp, mod_util, ts.strftime("%Y-%m-%d %H:%M:00")
            )
            room_temp = next_room_temp
        else:
            result = step_room_dynamics(
                room_temp_c=room_temp, outdoor_temp_c=mod_temp, utilization=mod_util,
                dt_seconds=dt_seconds,
                num_servers=rollout_cfg.datacenter.num_servers,
                rated_power_per_server_kw=rollout_cfg.datacenter.rated_power_per_server_kw,
                airflow_m3_per_s=rollout_cfg.thermal.airflow_m3_per_s,
                air_density=rollout_cfg.thermal.air_density,
                specific_heat_air=rollout_cfg.thermal.specific_heat_air,
                room_thermal_mass_kj_per_c=rollout_cfg.thermal.room_thermal_mass_kj_per_c,
                free_cooling_threshold_c=rollout_cfg.cooling.free_cooling_threshold_c,
                mixed_mode_threshold_c=rollout_cfg.cooling.mixed_mode_threshold_c,
                chiller_cop_rated=rollout_cfg.cooling.chiller_cop_rated,
                chiller_cop_min=rollout_cfg.cooling.chiller_cop_min,
                cop_ref_outdoor_temp_c=rollout_cfg.cooling.cop_ref_outdoor_temp_c,
                chiller_max_capacity_kw=rollout_cfg.cooling.chiller_max_capacity_kw,
                target_temp_c=rollout_cfg.thermal.target_temp_c,
                chiller_capacity_ratio=chiller_ratio,
                temp_safety_min_c=rollout_cfg.thermal.temp_safety_min_c,
                temp_safety_max_c=rollout_cfg.thermal.temp_safety_max_c,
            )
            mode, pue, viol = result.mode, result.pue, result.temp_violation
            room_temp = result.room_temp_c

        valid_pue = pue if pue == pue else 0.0
        settings.append(RolloutPoint(
            timestamp=ts.isoformat(), outdoor_temp_c=round(mod_temp, 2), it_utilization=round(mod_util, 3),
            mode=mode, room_temp_c=round(room_temp, 3), pue=round(valid_pue, 4),
            temp_violation=viol, chiller_capacity_ratio=chiller_ratio,
        ))

    pues = [s.pue for s in settings if s.pue > 0]
    return RolloutResponse(
        config_name=req.config_name,
        horizon_hours=req.horizon_hours,
        strategy=req.strategy,
        expected_avg_pue=round(sum(pues) / len(pues), 4) if pues else 0.0,
        expected_max_temp_c=round(max(s.room_temp_c for s in settings), 2),
        temp_violation_count=sum(1 for s in settings if s.temp_violation),
        settings=settings,
    )


if __name__ == "__main__":
    uvicorn.run("src.main:app", host="0.0.0.0", port=8000, reload=True)