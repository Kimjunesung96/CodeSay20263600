from src.ml.mpc import run_rl_mpc, _get_forecast, _rollout_cost, HORIZON_STEPS


def test_get_forecast_returns_correct_length():
    temps, utils = _get_forecast(30.0, 0.7, None)
    assert len(temps) == HORIZON_STEPS
    assert len(utils) == HORIZON_STEPS


def test_rollout_cost_returns_valid_result():
    temps = [30.0] * HORIZON_STEPS
    utils = [0.8] * HORIZON_STEPS
    cost, first_result = _rollout_cost(24.0, 24.0, temps, utils)
    assert cost >= 0
    assert first_result is not None
    assert first_result.mode in ["free", "mixed", "chiller"]


def test_run_rl_mpc_returns_valid_tuple():
    mode, power, temp, pue, viol = run_rl_mpc(
        current_room_temp_c=24.0, current_outdoor_temp_c=32.0, current_it_utilization=0.8
    )
    assert mode in ["free", "mixed", "chiller"]
    assert power >= 0
    assert isinstance(temp, float)
    assert pue >= 0
    assert isinstance(viol, bool)


def test_run_rl_mpc_never_exceeds_safety_in_normal_capacity():
    # 정상 용량 상황에서 MPC가 위험한 선택을 하지 않는지 (안전 위반 없어야 함)
    mode, power, temp, pue, viol = run_rl_mpc(
        current_room_temp_c=24.0, current_outdoor_temp_c=39.0, current_it_utilization=0.95
    )
    assert viol is False


def test_run_rl_mpc_saves_more_or_equal_power_than_fixed_setpoint():
    # MPC가 고정 24도 유지보다 칠러전력을 더 쓰지는 않아야 함 (같거나 적어야 함)
    from src.thermal_model.room_dynamics import step_room_dynamics
    from src.ml.mpc import cfg as mpc_cfg

    rule_based_res = step_room_dynamics(
        room_temp_c=24.0, outdoor_temp_c=32.0, utilization=0.8, dt_seconds=300,
        num_servers=mpc_cfg.datacenter.num_servers,
        rated_power_per_server_kw=mpc_cfg.datacenter.rated_power_per_server_kw,
        airflow_m3_per_s=mpc_cfg.thermal.airflow_m3_per_s,
        air_density=mpc_cfg.thermal.air_density,
        specific_heat_air=mpc_cfg.thermal.specific_heat_air,
        room_thermal_mass_kj_per_c=mpc_cfg.thermal.room_thermal_mass_kj_per_c,
        free_cooling_threshold_c=mpc_cfg.cooling.free_cooling_threshold_c,
        mixed_mode_threshold_c=mpc_cfg.cooling.mixed_mode_threshold_c,
        chiller_cop_rated=mpc_cfg.cooling.chiller_cop_rated,
        chiller_cop_min=mpc_cfg.cooling.chiller_cop_min,
        cop_ref_outdoor_temp_c=mpc_cfg.cooling.cop_ref_outdoor_temp_c,
        chiller_max_capacity_kw=mpc_cfg.cooling.chiller_max_capacity_kw,
        target_temp_c=mpc_cfg.thermal.target_temp_c,
    )

    _, mpc_power, _, _, _ = run_rl_mpc(24.0, 32.0, 0.8)
    assert mpc_power <= rule_based_res.chiller_power_kw + 1e-6
