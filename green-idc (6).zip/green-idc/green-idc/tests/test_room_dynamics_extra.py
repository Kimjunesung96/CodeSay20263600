from src.config_loader import load_config
from src.thermal_model.room_dynamics import step_room_dynamics, determine_mode

cfg = load_config("configs/base.yaml")

COMMON = dict(
    num_servers=cfg.datacenter.num_servers,
    rated_power_per_server_kw=cfg.datacenter.rated_power_per_server_kw,
    airflow_m3_per_s=cfg.thermal.airflow_m3_per_s,
    air_density=cfg.thermal.air_density,
    specific_heat_air=cfg.thermal.specific_heat_air,
    room_thermal_mass_kj_per_c=cfg.thermal.room_thermal_mass_kj_per_c,
    free_cooling_threshold_c=cfg.cooling.free_cooling_threshold_c,
    mixed_mode_threshold_c=cfg.cooling.mixed_mode_threshold_c,
    chiller_cop_rated=cfg.cooling.chiller_cop_rated,
    chiller_cop_min=cfg.cooling.chiller_cop_min,
    cop_ref_outdoor_temp_c=cfg.cooling.cop_ref_outdoor_temp_c,
    chiller_max_capacity_kw=cfg.cooling.chiller_max_capacity_kw,
    target_temp_c=cfg.thermal.target_temp_c,
    temp_safety_min_c=cfg.thermal.temp_safety_min_c,
    temp_safety_max_c=cfg.thermal.temp_safety_max_c,
)


def test_determine_mode_boundaries():
    assert determine_mode(10.0, free_threshold=15.0, mixed_threshold=22.0) == "free"
    assert determine_mode(15.0, free_threshold=15.0, mixed_threshold=22.0) == "free"
    assert determine_mode(18.0, free_threshold=15.0, mixed_threshold=22.0) == "mixed"
    assert determine_mode(30.0, free_threshold=15.0, mixed_threshold=22.0) == "chiller"


def test_chiller_failure_causes_temp_rise():
    # 정상 용량(1.0)이면 온도가 유지되지만, 완전 고장(0.0)이면 온도가 상승해야 함
    res_normal = step_room_dynamics(
        room_temp_c=24.0, outdoor_temp_c=35.0, utilization=0.9,
        dt_seconds=300, chiller_capacity_ratio=1.0, **COMMON,
    )
    res_failure = step_room_dynamics(
        room_temp_c=24.0, outdoor_temp_c=35.0, utilization=0.9,
        dt_seconds=300, chiller_capacity_ratio=0.0, **COMMON,
    )
    assert res_failure.room_temp_c > res_normal.room_temp_c
    assert res_failure.unmet_load_kw > res_normal.unmet_load_kw


def test_temp_violation_flag_triggers_above_safety_max():
    # 극단적 상황(칠러 완전고장 + 폭염)을 여러 스텝 반복하면 27도를 넘어서야 함
    temp = 24.0
    violated = False
    for _ in range(20):
        res = step_room_dynamics(
            room_temp_c=temp, outdoor_temp_c=40.0, utilization=0.95,
            dt_seconds=300, chiller_capacity_ratio=0.0, **COMMON,
        )
        temp = res.room_temp_c
        if res.temp_violation:
            violated = True
            break
    assert violated is True


def test_room_recovers_when_capacity_restored():
    # 온도가 튀어도(위기), 용량이 회복되면 다시 목표온도로 돌아와야 함
    temp = 30.0  # 이미 튄 상태에서 시작
    for _ in range(50):
        res = step_room_dynamics(
            room_temp_c=temp, outdoor_temp_c=25.0, utilization=0.5,
            dt_seconds=300, chiller_capacity_ratio=1.0, **COMMON,
        )
        temp = res.room_temp_c
    assert abs(temp - cfg.thermal.target_temp_c) < 0.5
