import pytest
from src.thermal_model.cooling_model import (
    calc_it_power_kw, 
    calc_free_cooling_capacity_kw, 
    calc_chiller_cop
)
from src.thermal_model.room_dynamics import step_room_dynamics
from src.config_loader import load_config

# 테스트용 기본 설정 로드
cfg = load_config("configs/base.yaml")

def test_calc_it_power():
    # 500대 서버, 대당 0.4kW, 50% 부하율 = 100kW
    it_power = calc_it_power_kw(num_servers=500, rated_power_per_server_kw=0.4, utilization=0.5)
    assert it_power == 100.0

def test_free_cooling_capacity():
    # 외기온 15도, 목표 24도 일 때 자연공조 용량 발생 확인
    capacity = calc_free_cooling_capacity_kw(
        outdoor_temp_c=15.0, 
        target_temp_c=24.0, 
        airflow_m3_per_s=25.0, 
        air_density=1.2, 
        specific_heat_air=1.005
    )
    assert capacity > 0.0

def test_chiller_cop():
    # 더운 날(38도 이상)에는 최저 COP(2.8)가 나와야 함
    cop = calc_chiller_cop(
        outdoor_temp_c=39.0, 
        cop_rated=4.3, 
        cop_min=2.8, 
        cop_ref_outdoor_temp_c=38.0
    )
    assert cop == 2.8

def test_room_dynamics_step():
    # 룸 동역학 1스텝 실행 후 결과 객체가 정상 반환되는지 확인
    res = step_room_dynamics(
        room_temp_c=24.0,
        outdoor_temp_c=30.0,
        utilization=0.8,
        dt_seconds=300,
        num_servers=cfg.datacenter.num_servers,
        rated_power_per_server_kw=cfg.datacenter.rated_power_per_server_kw,
        airflow_m3_per_s=cfg.thermal.airflow_m3_per_s,
        air_density=cfg.thermal.air_density,
        specific_heat_air=cfg.thermal.specific_heat_air,
        room_thermal_mass_kj_per_c=cfg.thermal.room_thermal_mass_kj_per_c,
        free_cooling_threshold_c=cfg.cooling.free_cooling_threshold_c,
        mixed_mode_threshold_c=cfg.cooling.mixed_mode_threshold_c,
        chiller_cop_rated=cfg.cooling.chiller_cop_rated,
        chiller_cop_min=cfg.cooling.chiller_cop_min,
        cop_ref_outdoor_temp_c=cfg.cooling.cop_ref_outdoor_temp_c,
        chiller_max_capacity_kw=cfg.cooling.chiller_max_capacity_kw,
        target_temp_c=cfg.thermal.target_temp_c
    )
    
    assert res.room_temp_c > 0
    assert res.mode in ["free", "mixed", "chiller"]
    assert res.pue >= 1.0