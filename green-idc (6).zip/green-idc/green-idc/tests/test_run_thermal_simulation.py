from src.config_loader import load_config
from src.simulator.run_thermal_simulation import apply_crisis_scenarios, run_thermal_simulation


def test_apply_crisis_scenarios_no_crisis_when_disabled():
    cfg = load_config("configs/base.yaml")  # base.yaml은 모든 crisis가 꺼져있음
    outdoor, util, ratio = apply_crisis_scenarios(10.0, 30.0, 0.7, cfg)
    assert outdoor == 30.0
    assert util == 0.7
    assert ratio == 1.0


def test_apply_crisis_scenarios_heatwave_override():
    cfg = load_config("configs/experiment_crisis_heatwave.yaml")
    hw = cfg.crisis.heatwave
    assert hw.enabled is True

    # 폭염 적용 구간 안
    inside_hour = hw.start_hour + 1
    outdoor, _, _ = apply_crisis_scenarios(inside_hour, 20.0, 0.5, cfg)
    assert outdoor == hw.outdoor_temp_override_c

    # 폭염 적용 구간 밖 (시작 전)
    outside_hour = hw.start_hour - 1
    outdoor_before, _, _ = apply_crisis_scenarios(outside_hour, 20.0, 0.5, cfg)
    assert outdoor_before == 20.0


def test_apply_crisis_scenarios_server_surge_increases_utilization():
    cfg = load_config("configs/experiment_crisis_server_surge.yaml")
    surge = cfg.crisis.server_surge
    assert surge.enabled is True

    _, util, _ = apply_crisis_scenarios(0.0, 25.0, 0.5, cfg)
    assert util > 0.5
    assert util <= 1.0  # 상한 클리핑 확인


def test_apply_crisis_scenarios_chiller_failure_reduces_capacity():
    cfg = load_config("configs/experiment_crisis_chiller_failure.yaml")
    fail = cfg.crisis.chiller_failure
    assert fail.enabled is True

    inside_hour = fail.start_hour + 1
    _, _, ratio = apply_crisis_scenarios(inside_hour, 25.0, 0.5, cfg)
    assert ratio == fail.capacity_ratio

    outside_hour = fail.start_hour + fail.duration_hours + 1
    _, _, ratio_after = apply_crisis_scenarios(outside_hour, 25.0, 0.5, cfg)
    assert ratio_after == 1.0


def test_run_thermal_simulation_small_normal_case():
    cfg = load_config("configs/base.yaml")
    cfg.simulation.duration_days = 1  # 빠르게 돌리기 위해 축소
    df = run_thermal_simulation(cfg)

    expected_periods = int(cfg.simulation.duration_days * 24 * 60 / cfg.simulation.interval_minutes)
    assert len(df) == expected_periods
    assert "room_temp_c" in df.columns
    assert "temp_violation" in df.columns
    # 정상 시나리오(위기 없음)에서는 온도 위반이 없어야 함
    assert df["temp_violation"].sum() == 0


def test_run_thermal_simulation_chiller_failure_can_violate():
    cfg = load_config("configs/experiment_crisis_chiller_failure.yaml")
    cfg.simulation.duration_days = 1
    # 고장 시점을 낮 시간(칠러가 실제로 필요한 시간대)으로 맞춰서 확실히 재현
    cfg.crisis.chiller_failure.start_hour = 11
    cfg.crisis.chiller_failure.duration_hours = 6

    df = run_thermal_simulation(cfg)
    # 완전 고장 상황이므로 최고온도가 초기값(24도)보다는 확실히 높아야 함
    assert df["room_temp_c"].max() > cfg.thermal.initial_room_temp_c
