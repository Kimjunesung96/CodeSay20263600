from src.evaluation.esg import (
    calculate_carbon_emission_tco2,
    calculate_wue,
    estimate_chiller_water_usage_l,
)


def test_carbon_emission_zero():
    assert calculate_carbon_emission_tco2(0) == 0.0


def test_carbon_emission_known_value():
    # 1000kWh = 1MWh -> 0.459 tCO2
    assert calculate_carbon_emission_tco2(1000) == 0.459


def test_wue_normal():
    # 물 100L / 전력 50kWh = 2.0
    assert calculate_wue(100, 50) == 2.0


def test_wue_zero_energy_guard():
    # 0으로 나누기 방지 -> 0.0 리턴
    assert calculate_wue(100, 0) == 0.0
    assert calculate_wue(100, -5) == 0.0


def test_chiller_water_usage():
    assert estimate_chiller_water_usage_l(10) == 18.0
    assert estimate_chiller_water_usage_l(0) == 0.0
