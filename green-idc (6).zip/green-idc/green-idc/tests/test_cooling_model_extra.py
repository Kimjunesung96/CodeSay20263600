from src.thermal_model.cooling_model import run_cooling_step


COMMON = dict(
    num_servers=500,
    rated_power_per_server_kw=0.4,
    target_temp_c=24.0,
    airflow_m3_per_s=25.0,
    air_density=1.2,
    specific_heat_air=1.005,
    free_cooling_threshold_c=15.0,
    mixed_mode_threshold_c=22.0,
    chiller_cop_rated=4.3,
    chiller_cop_min=2.8,
    cop_ref_outdoor_temp_c=38.0,
)


def test_free_cooling_mode_on_cold_day():
    # 외기 5도(임계 15도 이하) -> 자연공조만 사용, 칠러 0
    res = run_cooling_step(outdoor_temp_c=5.0, utilization=0.8, **COMMON)
    assert res.mode == "free"
    assert res.chiller_power_kw == 0.0
    assert res.pue == 1.0  # 냉각에 추가전력이 안 들어가므로 PUE는 1.0


def test_chiller_mode_on_hot_day():
    # 외기 32도(임계 22도 초과) -> 칠러 가동, PUE가 1.0보다 커야 함
    res = run_cooling_step(outdoor_temp_c=32.0, utilization=0.8, **COMMON)
    assert res.mode == "chiller"
    assert res.chiller_power_kw > 0.0
    assert res.pue > 1.0


def test_mixed_mode_between_thresholds():
    # 15~22도 사이 -> mixed 모드
    res = run_cooling_step(outdoor_temp_c=18.0, utilization=0.5, **COMMON)
    assert res.mode == "mixed"


def test_zero_utilization_gives_zero_it_power():
    res = run_cooling_step(outdoor_temp_c=25.0, utilization=0.0, **COMMON)
    assert res.it_power_kw == 0.0
    # IT 전력이 0이면 PUE 계산은 nan으로 처리됨 (0으로 나누기 방지)
    assert res.pue != res.pue  # NaN 체크


def test_extreme_hot_day_uses_min_cop():
    # cop_ref_outdoor_temp_c(38도) 이상이면 최저 COP가 적용됨
    res_at_ref = run_cooling_step(outdoor_temp_c=38.0, utilization=0.8, **COMMON)
    res_above_ref = run_cooling_step(outdoor_temp_c=45.0, utilization=0.8, **COMMON)
    assert res_at_ref.chiller_cop == COMMON["chiller_cop_min"]
    assert res_above_ref.chiller_cop == COMMON["chiller_cop_min"]
