import pytest
from fastapi.testclient import TestClient
from src.main import app

client = TestClient(app)

def test_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok", "message": "Green IDC API is running."}

def test_forecast_api():
    payload = {
        "timestamp": "2024-09-15 12:00:00",
        "lookahead_steps": 6
    }
    response = client.post("/forecast", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "predicted_outdoor_temp_c" in data
    assert "predicted_it_utilization" in data
    assert len(data["predicted_outdoor_temp_c"]) == 6

def test_control_optimize_api():
    payload = {
        "current_room_temp_c": 24.0,
        "current_outdoor_temp_c": 32.0,
        "current_it_utilization": 0.8
    }
    response = client.post("/control/optimize", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "recommended_mode" in data
    assert "target_chiller_power_kw" in data
    assert "pue" in data