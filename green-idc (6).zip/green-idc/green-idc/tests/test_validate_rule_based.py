import re

from src.evaluation.validate_rule_based import evaluate_config


def _set_duration_days(content: str, days: int) -> str:
    """base.yaml 안의 duration_days 값이 얼마든(90이든 365든) 안전하게 교체."""
    return re.sub(r"duration_days:\s*\d+", f"duration_days: {days}", content)


def _make_small_config(tmp_path):
    """base.yaml을 복제해서 duration_days만 1로 줄인 임시 config 생성."""
    with open("configs/base.yaml", "r", encoding="utf-8") as f:
        content = f.read()
    content = _set_duration_days(content, 1)
    out_path = tmp_path / "tiny_base.yaml"
    out_path.write_text(content, encoding="utf-8")
    return str(out_path)


def test_evaluate_config_normal_case_passes_maintain_rate(tmp_path):
    config_path = _make_small_config(tmp_path)
    result = evaluate_config(config_path)

    assert result["steps"] == 288  # 1일 x 24시간 x 12스텝(5분간격)
    assert result["maintain_rate_pct"] >= 0
    assert "maintain_pass(>=95%)" in result
    assert result["crisis_scenario"] is False
    assert result["crisis_pass(<=27C)"] is None  # 위기시나리오 아니므로 None


def test_evaluate_config_detects_crisis_experiment(tmp_path):
    with open("configs/experiment_crisis_chiller_failure.yaml", "r", encoding="utf-8") as f:
        content = f.read()
    content = _set_duration_days(content, 1)
    config_path = tmp_path / "tiny_crisis.yaml"
    config_path.write_text(content, encoding="utf-8")

    result = evaluate_config(str(config_path))
    assert result["crisis_scenario"] is True
    assert result["crisis_pass(<=27C)"] in [True, False]  # None이 아니라 실제 판정값이어야 함
