import numpy as np
import pandas as pd
import pytest

from src.config_loader import load_config
from src.simulator.generate_dataset import (
    generate_weather_series,
    generate_utilization_series,
    try_load_real_weather,
    try_load_real_utilization,
    run_simulation,
)


@pytest.fixture
def small_cfg():
    """전체 90일 대신 1일치로 빠르게 도는 테스트용 config."""
    cfg = load_config("configs/base.yaml")
    cfg.simulation.duration_days = 1
    cfg.experiment_name = "test_tmp_small"
    return cfg


def test_generate_weather_series_shape_and_range(small_cfg):
    rng = np.random.default_rng(42)
    periods = int(small_cfg.simulation.duration_days * 24 * 60 / small_cfg.simulation.interval_minutes)
    timestamps = pd.date_range(small_cfg.simulation.start_date, periods=periods, freq="5min")
    temps = generate_weather_series(timestamps, small_cfg.simulation, rng)
    assert len(temps) == periods
    # 극단적으로 비현실적인 값은 아닌지 (대략적인 범위 체크)
    assert temps.min() > -30
    assert temps.max() < 60


def test_generate_utilization_series_within_bounds(small_cfg):
    rng = np.random.default_rng(42)
    periods = int(small_cfg.simulation.duration_days * 24 * 60 / small_cfg.simulation.interval_minutes)
    timestamps = pd.date_range(small_cfg.simulation.start_date, periods=periods, freq="5min")
    util = generate_utilization_series(timestamps, small_cfg.datacenter, rng)
    assert util.min() >= small_cfg.datacenter.min_it_utilization - 1e-6
    assert util.max() <= small_cfg.datacenter.max_it_utilization + 1e-6


def test_try_load_real_weather_returns_none_without_cache(tmp_path, small_cfg):
    small_cfg.raw_data_dir = str(tmp_path)  # 빈 폴더 -> 캐시 없음
    timestamps = pd.date_range(small_cfg.simulation.start_date, periods=10, freq="5min")
    result = try_load_real_weather(small_cfg, timestamps)
    assert result is None


def test_try_load_real_weather_uses_cache_when_present(tmp_path, small_cfg):
    small_cfg.raw_data_dir = str(tmp_path)
    periods = 300
    timestamps = pd.date_range(small_cfg.simulation.start_date, periods=periods, freq="5min")

    fake_df = pd.DataFrame({
        "timestamp": timestamps,
        "outdoor_temp_c": np.linspace(10, 20, periods),
    })
    fake_df.to_parquet(tmp_path / "real_weather_test_00000000_99999999.parquet", index=False)

    result = try_load_real_weather(small_cfg, timestamps)
    assert result is not None
    assert len(result) == periods
    assert not np.isnan(result).any()


def test_try_load_real_utilization_returns_none_without_cache(tmp_path, small_cfg):
    small_cfg.raw_data_dir = str(tmp_path)
    timestamps = pd.date_range(small_cfg.simulation.start_date, periods=10, freq="5min")
    result = try_load_real_utilization(small_cfg, timestamps)
    assert result is None


def test_try_load_real_utilization_uses_cache_when_present(tmp_path, small_cfg):
    small_cfg.raw_data_dir = str(tmp_path)
    periods = 300
    timestamps = pd.date_range(small_cfg.simulation.start_date, periods=periods, freq="5min")

    fake_df = pd.DataFrame({
        "timestamp": timestamps,
        "it_utilization": np.full(periods, 0.6),
    })
    fake_df.to_parquet(tmp_path / "real_it_load.parquet", index=False)

    result = try_load_real_utilization(small_cfg, timestamps)
    assert result is not None
    assert np.allclose(result, 0.6)


def test_run_simulation_produces_expected_columns(small_cfg, tmp_path):
    small_cfg.raw_data_dir = str(tmp_path)  # 실데이터 캐시 없이 순수 합성으로만 테스트
    df = run_simulation(small_cfg)

    expected_periods = int(small_cfg.simulation.duration_days * 24 * 60 / small_cfg.simulation.interval_minutes)
    assert len(df) == expected_periods
    for col in ["outdoor_temp_c", "it_utilization", "pue", "mode", "total_power_kw"]:
        assert col in df.columns
    assert df["mode"].isin(["free", "mixed", "chiller"]).all()
    assert (df["pue"] >= 1.0).all()
