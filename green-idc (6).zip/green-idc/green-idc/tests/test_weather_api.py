import os
import pandas as pd
import pytest

from src.data.weather_api import interpolate_to_interval, _get_service_key


def test_get_service_key_raises_without_env(monkeypatch):
    monkeypatch.delenv("WEATHER_API_KEY", raising=False)
    with pytest.raises(RuntimeError):
        _get_service_key()


def test_get_service_key_returns_value_when_set(monkeypatch):
    monkeypatch.setenv("WEATHER_API_KEY", "dummy-key-123")
    assert _get_service_key() == "dummy-key-123"


def test_interpolate_to_interval_fills_hourly_to_5min():
    hourly = pd.date_range("2024-06-01 00:00", "2024-06-01 03:00", freq="1h")
    df = pd.DataFrame({"timestamp": hourly, "outdoor_temp_c": [10.0, 12.0, 14.0, 16.0]})

    result = interpolate_to_interval(df, interval_minutes=5)

    # 1시간(60분) / 5분 = 12개 구간 + 1 = 37개 포인트가 나와야 함 (0~180분)
    assert len(result) == 37
    assert "outdoor_temp_c" in result.columns
    # 보간이므로 시작/끝 값은 원본과 같아야 함
    assert result["outdoor_temp_c"].iloc[0] == 10.0
    assert result["outdoor_temp_c"].iloc[-1] == 16.0
    # 중간값은 선형보간되어 원본 범위 안에 있어야 함
    assert result["outdoor_temp_c"].between(10.0, 16.0).all()
