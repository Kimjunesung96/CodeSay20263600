import pandas as pd

from src.data.fetch_cluster_trace import process_cluster_trace


def test_process_cluster_trace_normalizes_and_interpolates(tmp_path):
    # 가짜 Cluster Trace CSV (시간초, CPU사용률 0~100 스케일)
    csv_path = tmp_path / "fake_trace.csv"
    df = pd.DataFrame({
        "time_sec": [0, 3600, 7200, 10800],
        "cpu_usage": [20.0, 50.0, 80.0, 40.0],
    })
    df.to_csv(csv_path, index=False)

    result = process_cluster_trace(str(csv_path), interval_minutes=5, start_date="2024-06-01")

    assert "timestamp" in result.columns
    assert "it_utilization" in result.columns
    # 0~100 스케일이 0~1로 정규화됐는지
    assert result["it_utilization"].max() <= 0.95
    assert result["it_utilization"].min() >= 0.15
    # 1시간(3600초) 구간을 5분 간격으로 리샘플링하면 13개 포인트가 나와야 함
    assert len(result) == 37  # 0~10800초 = 3시간, 5분 간격 = 36구간+1


def test_process_cluster_trace_already_normalized_scale(tmp_path):
    # 이미 0~1 스케일인 경우 100으로 나누면 안 됨
    csv_path = tmp_path / "fake_trace_normalized.csv"
    df = pd.DataFrame({
        "time_sec": [0, 3600],
        "cpu_usage": [0.3, 0.7],
    })
    df.to_csv(csv_path, index=False)

    result = process_cluster_trace(str(csv_path), interval_minutes=5, start_date="2024-06-01")
    # 0.3~0.7 스케일이 그대로(혹은 clip 범위 안에서) 유지되어야 함
    assert result["it_utilization"].max() <= 0.95
    assert result["it_utilization"].min() >= 0.15
