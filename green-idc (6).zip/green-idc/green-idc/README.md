# Green IDC - 데이터센터 지능형 냉각/전력 최적화 (Codyssey 22번)

## 설치

```bash
pip install -r requirements.txt
```

## 폴더 구조

```
green-idc/
├── configs/
│   ├── base.yaml                              # 기본(정상) 시뮬레이션 설정
│   ├── experiment_crisis_chiller_failure.yaml # 위기: 칠러 완전고장 6시간
│   ├── experiment_crisis_heatwave.yaml        # 위기: 폭염 39도 24시간
│   └── experiment_crisis_server_surge.yaml    # 위기: 서버부하 +30%
├── src/
│   ├── config_loader.py          # yaml -> 파이썬 객체 변환
│   ├── thermal_model/
│   │   ├── cooling_model.py      # 열역학 기본 공식 (Q=mcpΔT, COP, PUE)
│   │   └── room_dynamics.py      # 상태유지형(stateful) 서버룸 온도 동역학 + 제어로직
│   ├── simulator/
│   │   ├── generate_dataset.py       # 기상/IT부하 합성 시계열 생성
│   │   └── run_thermal_simulation.py # 90일 전체 stateful 시뮬레이션 러너
│   └── evaluation/
│       └── validate_rule_based.py    # 성능기준(온도유지율 95%+, 위기시나리오 27도) 검증
├── data/processed/<experiment_name>/  # 실행 결과 parquet 저장 위치
└── results/rule_based_validation.csv  # 검증 결과 요약표
```

## 실행 순서

### 0. (선택) 실제 기상청 날씨 데이터 연동
지금까지는 sin함수로 만든 가짜 날씨였는데, 이제 실제 관측값을 쓸 수 있어요.

```powershell
$env:WEATHER_API_KEY="공공데이터포털에서 발급받은 일반 인증키(Decoding)"
python src/data/fetch_real_weather.py --config configs/base.yaml --station 119
```
- `--station`: 기상청 지점번호. 기본 119=수원. 서울108, 인천112, 평택201 등
- 성공하면 `data/raw/real_weather_119_20240601_20240829.parquet` 캐시가 생김
- 이 캐시가 있으면 `generate_dataset.py`, `run_thermal_simulation.py`가 **자동으로** 합성 날씨 대신 이 실데이터를 사용함 (코드 수정 불필요)
- 캐시가 없으면 자동으로 기존 합성 날씨로 폴백 (에러 안 남)

### 1. 열역학 모델 단독 테스트 (더운 날 vs 추운 날 PUE 확인)
```bash
PYTHONPATH=. python3 src/thermal_model/cooling_model.py
```

### 2. 서버룸 온도 동역학 단독 테스트 (정상 vs 칠러고장+폭염)
```bash
PYTHONPATH=. python3 src/thermal_model/room_dynamics.py
```

### 3. 90일 시계열 데이터셋 생성 (IT부하/기상 합성, 정적 계산)
```bash
PYTHONPATH=. python3 src/simulator/generate_dataset.py --config configs/base.yaml
```
결과: `data/processed/base/timeseries.parquet`

### 4. 90일 stateful 열동역학 시뮬레이션 (온도가 시간에 따라 실제로 변함)
```bash
PYTHONPATH=. python3 src/simulator/run_thermal_simulation.py --config configs/base.yaml
```
결과: `data/processed/base/thermal_timeseries.parquet`

위기시나리오도 동일하게:
```bash
PYTHONPATH=. python3 src/simulator/run_thermal_simulation.py --config configs/experiment_crisis_chiller_failure.yaml
PYTHONPATH=. python3 src/simulator/run_thermal_simulation.py --config configs/experiment_crisis_heatwave.yaml
PYTHONPATH=. python3 src/simulator/run_thermal_simulation.py --config configs/experiment_crisis_server_surge.yaml
```

### 5. 전체 성능기준 검증 (base + 위기시나리오 3개 한번에 돌려서 요약표 생성)
```bash
PYTHONPATH=. python3 src/evaluation/validate_rule_based.py
```
결과: `results/rule_based_validation.csv` + 콘솔에 PASS/FAIL 출력

### 6. REST API 서버 실행
```bash
uvicorn src.api.main:app --reload --port 8000
```
브라우저에서 `http://localhost:8000/docs` 열면 Swagger UI로 바로 테스트 가능.

엔드포인트:
- `GET /health` - 헬스체크
- `POST /api/v1/forecast` - IT부하/냉각수요 예측 (현재는 naive placeholder, ±10% 밴드)
- `POST /api/v1/control/optimize` - Rule-based 제어 롤아웃 (예상 PUE/최고온도/위반횟수 반환)
- `POST /api/v1/control/mpc` - MPC 미구현, 현재는 optimize와 동일 결과 반환하는 stub

요청 예시 (`optimize`):
```json
{
  "config_name": "base",
  "horizon_hours": 24,
  "current_room_temp_c": 24.0
}
```

## 현재까지 구현된 것

- [x] 열역학 모델 직접구현 (Q=ṁ×cp×ΔT, COP=외기온도함수, FreeCooling)
- [x] 90일+ 5분단위 시계열 (합성 데이터, 실데이터 미연동)
- [x] 외기 15도 이하 자연공조 전환
- [x] 서버룸 열용량 기반 온도 동역학 (냉각부족 -> 실제 온도상승)
- [x] Rule-based 제어 (목표온도로 피드백 복귀)
- [x] 위기시나리오 3종: 서버급증(+30%), 냉각기고장, 폭염(39도)
- [x] 온도유지율 95%+ / 위기시 27도 이하 검증 스크립트
- [x] FastAPI 뼈대: forecast / control/optimize / control/mpc(stub) 3개 엔드포인트
- [x] 기상청 ASOS 실제 관측 기온 연동 (캐시 있으면 자동 사용, 없으면 합성 데이터 폴백)

## 아직 안 된 것 (스펙 대비 남은 작업)

- [ ] Google Cluster Trace 2019 (IT부하 실데이터) 연동 - 날씨는 됐지만 부하는 아직 합성
- [ ] IT부하/냉각수요 실제 예측 모델 (MAPE 24h≤5%, 168h≤8%) - 지금은 naive placeholder
- [ ] MPC 또는 RL 제어기 실구현 (Rule-based 대비 10%+ 개선 검증) - 지금은 rule-based로 우회
- [ ] control/optimize, control/mpc가 아직 crisis_scenarios(config의 chiller_failure 등)를 반영 안 함 - 항상 정상상태로 롤아웃
- [ ] Streamlit 대시보드
- [ ] ESG 분석 (탄소배출 0.459tCO2/MWh, WUE)
- [ ] Sinergym 대비 오차 검증, NAVER 춘천 PUE 1.09 벤치마크 비교
- [ ] pytest 테스트 코드 (커버리지 60%+)
- [ ] Docker화
